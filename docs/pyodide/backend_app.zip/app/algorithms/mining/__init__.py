"""Subgroup mining package."""
