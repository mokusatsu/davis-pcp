"""Penalty-Reward Analysis package."""
