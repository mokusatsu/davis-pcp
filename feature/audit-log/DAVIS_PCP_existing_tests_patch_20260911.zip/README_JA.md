# DAVIS-PCP 既存テスト：確定仕様への追従patch

作成日：2026-09-11

## 1. 対象と成果物

利用者が指定した`tests.zip`そのものを基準に作成したGit unified diffです。

- 入力ZIPのSHA-256：`289c8b06b829e6c02944551ca46a60b8d3a26ce942c44fc1cda18d161adfa13d`
- ZIP内の`tests/`はプロジェクトの`backend/tests/`に対応します。
- 主patch：`davis_pcp_existing_tests_contracts.patch`
- 補助patch：`davis_pcp_im02_stale_plan_409.patch`
- アプリ本体、共通fixture、既存の監査テストは変更していません。

主patchは6ファイルの既存テスト関数8件を更新し、補強テストを2件追加します。6ファイル内の残り55テスト関数はAST上不変です。主patchの適用後、この6ファイルのテスト関数数は63から65になります。これは関数数であり、pytestの通過件数ではありません。

補助patchは主patchに含みません。利用者の作業環境でIM02の409対応が済んでいる場合、主patchだけを適用してください。

## 2. 主patchの適用

`backend/`があるプロジェクトルートへpatchを置いて実行します。

```text
git apply --check davis_pcp_existing_tests_contracts.patch
git apply davis_pcp_existing_tests_contracts.patch
```

逆適用による取り消し：

```text
git apply --reverse --check davis_pcp_existing_tests_contracts.patch
git apply --reverse davis_pcp_existing_tests_contracts.patch
```

手元のテストに別の変更がある場合、まず`--check`の結果を確認してください。`--reject`や強制的な置換で文脈の違いを無視しないでください。補助patch適用済み・未適用のどちらの状態でも、主patchが適用できることを確認しました。

## 3. 8件の修正内容

|契約|対象|変更後の検証|
|---|---|---|
|V01|classic holdout|全件探索後の分割は`isExploratory=True`。pValue/pAdjusted/significant/replicationStatusはすべてNone。効果量・比較方向・候補固定・分割件数・世代不一致の拒否は検証を維持。|
|V01|classic cross-validation|同様に確認的推測を禁止。5fold各40件・計200件、各foldの全候補に有限の効果量、全体の群差10を確認。|
|V01|modern候補のholdout|modernで探索した固定候補も同じ事後的安定性の契約。候補ID集合と固定候補数を維持。|
|SN03|群差の感度分析|Welchの群差と95%区間を、テスト側の独立式で除外前後それぞれ照合。外れ値は1件、40件→39件。|
|AV02|加重集計|宣言領域[1,2]外の9を除外。設問有効N=5、設問の正重み合計=6、各カテゴリの加重人数3、50%/50%、加重平均1.5。|
|CTX04|復元抽出|2回ともHTTP422。成功した抽出結果や、非復元抽出への黙った代替を返さない。|
|PK01|予約ID持込み|通常のassign_row_identity経路では、一意な__rowId__であってもBizError/status_code=422。拒否時に入力値を変更しない。|
|SD02|層内PSU番号|PSUを(stratum, local PSU)で識別。5PSU・2層・自由度3。PSUを全体一意な名前に付け替えても数・自由度が一致。|

### V01：削除した旧期待と、その代わりに検証するもの

入力の`analysisMode="verification"`は既存クライアント向けの互換経路として維持しています。出力の同名フィールドの文字列だけで「独立検証」と判定しません。統計的な意味は`isExploratory`と各候補の推測フィールドで検証します。

旧期待の`mHypotheses >= 1`は、確認的に検定した仮説数を要求するため、`pinnedCandidateCount == len(results) >= 1`へ変更しました。空配列に対するall()だけで成功するテストにはしていません。

同じ理由で、事後的安定性に確認的なCIの存在や`testable=True`を強制しません。CIの具体的な有無や出力用ルート名を新たに推測する代わりに、有限の効果量、固定した群の方向、全foldの評価、候補集合の一貫性を確認します。`significant=False`も「検定して非有意」と区別できないため、確定仕様どおりNoneを要求します。

別標本によるindependent検証テストは変更していません。

### SN03：群差までStudent tへ置き換えない

`DAVIS_PCP_local2_fixed_spec_20260911.md`の§8は「単一平均の区間はStudent t(n-1)、群差はWelch tと名称も分ける」としています。既存の感度分析fixtureは2群の平均差なので、Welchの採用自体は正しいものです。

確定仕様には`confidenceMethod`の厳密なenum文字列が定義されていないため、旧文字列`welch_t_interval`との完全一致をやめています。群差では`welch`、単一平均では`student`を含む手法名であることを検証し、接尾辞の表記には拘束しません。どの方式で計算したかは、区間そのものを独立数式と突き合わせて検証します。単に「Noneではない」とする試験にはしていません。

既存fixtureのWelch区間（a群平均−b群平均）：

|状態|N|群差|95%区間|
|---|---:|---:|---|
|除外前|40|-13.8|[-22.0195534935, -5.5804465065]|
|100の外れ値を除外後|39|-9.8947368421|[-10.8230757314, -8.9663979528]|

追加した4件のKPI fixture `[1,2,3,4]` では平均2.5、自由度3、95%区間 `[0.4457397432, 4.5542602568]` を確認します。旧実装の固定1.96による区間を検出できます。API出力の4桁丸めに対する許容差は絶対誤差1e-4、相対許容差0です。

### AV02：scopeの重み合計と設問の有効分母を混同しない

元fixtureは `(Q1,wt)=[(1,1),(1,2),(2,3),(2,0),(9,5),(2,None)]` です。

このテストでは、既存APIのトップレベル`unweightedN=6`と`weightedN=11`はscope全体の旧フィールドとして維持しています。設問ごとの有効母数を示す`columns.Q1.weighted.weightedN`は6です。scopeの合計11を百分率や加重平均の分母に流用してはなりません。

非加重の有効回答は`[1,1,2,2,2]`の5件・平均1.6です。重み0や重み欠損は非加重回答そのものを無効化しません。一方、宣言外の9は非加重・加重ともに設問解析の有効値に入りません。トップレベルの旧フィールド名を廃止するAPI移行は、この8件の期待値修正には含めていません。

### PK01：内部フレーム経路は変更しない

通常取込のテストだけを拒否期待にします。検証済み内部フレームや正規パッケージ復元のバイパスに使う引数・関数名は、修正済み実装が添付されていないため推測して追加していません。明示した外部ID列の採用・保持を確認する既存テストは変更していません。

### SD02：旧テストの説明内の計算誤りも訂正

対象fixtureのs1にはa,b,cの3PSU、s2にはa,bの2PSUがあります。正しくは5PSU、設計自由度 `(3-1)+(2-1)=3` です。4や2ではありません。旧テストのdocstringとassertionはこのfixtureについて互いにも一致していなかったため、両方を訂正しています。

## 4. 改名対応表

テスト名に旧仕様の意味が残らないように一部を改名しています。CIなどでnode IDを個別指定している場合は更新してください。

|ファイル（backend/tests/からの相対）|旧名|新名|
|---|---|---|
|`api/test_mining_modes_api.py`|`test_verification_holdout_disjoint_and_adjusted`|`test_posthoc_holdout_preserves_split_and_suppresses_inference`|
|`api/test_mining_modes_api.py`|`test_verification_cross_validation_reports_folds_and_seed`|`test_posthoc_cross_validation_reports_folds_without_inference`|
|`api/test_mining_modes_api.py`|`test_modern_candidates_are_verified_through_the_pinned_set`|`test_modern_pinned_candidates_receive_posthoc_stability`|
|`api/test_sensitivity_api.py`|`test_sensitivity_compares_baseline_and_excluded`|`test_sensitivity_compares_baseline_and_excluded`|
|`api/test_survey_weight_api.py`|`test_weighted_mean_counts_pct_match_hand_values`|`test_weighted_mean_counts_pct_match_hand_values`|
|`unit/test_observations.py`|`test_sampling_with_replacement_reproducibility`|`test_sampling_with_replacement_is_rejected`|
|`unit/test_review_bugs_b01_b12.py`|`test_assign_row_identity_preserves_existing_unique_row_id`|`test_assign_row_identity_rejects_reserved_id_on_normal_import`|
|`unit/test_survey_rao_scott.py`|`test_design_df_is_the_global_psu_minus_strata_difference`|`test_design_df_counts_psus_nested_within_strata`|

追加の2関数：

```text
backend/tests/api/test_sensitivity_api.py::test_sensitivity_kpi_small_sample_uses_student_t
backend/tests/unit/test_observations.py::test_sampling_without_replacement_reproducibility
```

後者は、復元抽出の拒否テストへの変更によってseed再現性の検証自体を失わないための追加です。

## 5. IM02補助patch

指定されたZIP内では、`test_stale_plan_hash_is_rejected`の期待値はまだ422でした。利用者が説明した更新済みの作業ツリーとZIPに差があります。

補助patchはこの1箇所を409へ変更します。エラーコード`IMPUTATION_PLAN_STALE`は変えません。元ファイルのCRLFを保持しています。

既に409に変更済みの作業ツリーには適用しません。ZIPの未更新版をそのまま使う場合だけ、主patchとは別に実行してください。

```text
git apply --check davis_pcp_im02_stale_plan_409.patch
git apply davis_pcp_im02_stale_plan_409.patch
```

## 6. 実行方法（利用者の修正済みアプリ環境）

既存のテストはpytest形式なので、その形式を維持しています。今回の主patchの確認対象は次の6ファイルです。新しいPowerShellターミナルでプロジェクトルートを開き、プロジェクトの依存関係を導入済みのPythonで実行します。

```powershell
$env:PYTHONPATH = (Resolve-Path .\backend).Path
$env:DAVIS_PCP_WORKSPACE = Join-Path ([System.IO.Path]::GetTempPath()) ("davis-pcp-test-" + [Guid]::NewGuid().ToString("N"))

python -m pytest -q `
    backend/tests/api/test_mining_modes_api.py `
    backend/tests/api/test_sensitivity_api.py `
    backend/tests/api/test_survey_weight_api.py `
    backend/tests/unit/test_observations.py `
    backend/tests/unit/test_review_bugs_b01_b12.py `
    backend/tests/unit/test_survey_rao_scott.py
```

IM02の確認：

```powershell
python -m pytest -q backend/tests/api/test_imputation_plan_api.py::test_stale_plan_hash_is_rejected
```

実回答データのworkspaceを使わないでください。既存fixtureの中には固定datasetIdへ書き込むものがあります。上の設定は専用の一時workspaceを使います。生成されたテストデータはその一時ディレクトリに残るため、必要なログの確認後に削除してください。

## 7. この作業で実施した検証と、未実施の検証

|検証|結果|
|---|---|
|主patchのgit apply --check|PASS|
|主patchの実適用と作成済み6ファイルとのバイト一致|PASS|
|IM02が既に409でも主patchを適用可能|PASS|
|補助patchの実適用とCRLF保持|PASS|
|両patchの逆適用後に元のGit作業ツリーへ完全復元|PASS|
|git diff --check|PASS|
|主・補助patch適用後の79 Pythonファイルの構文コンパイル|PASS|
|既存8関数の変更・2関数の追加・残り55関数不変のAST確認|PASS|
|テスト側Welch式とSciPy ttest_ind(equal_var=False)の区間照合|PASS|
|KPI Student t区間、加重分母、入れ子PSU数の独立確認|PASS|
|posthoc assertion helperの単独確認|正常データ1件受理、不正データ9件拒否|
|修正済みアプリ本体に対するAPI/unit pytest実行|未実施|

現在参照できるアプリ本体は前回監査対象の`davis-pcp-local(2).zip`であり、利用者が今回説明した修正済み実装ではありません。そのため、このpatch適用後に最新アプリで65件が通過したとは報告していません。構文確認・独立数値照合・helperの単独実行は、APIテストの通過確認とは区別しています。

未確認のアプリ応答に合わせてp値のnull要求を緩めたり、失敗をskip/xfailへ変えたりはしていません。最新実装でこの契約に反する応答が残っている場合は、対応するテストが失敗します。

詳細な検証結果とファイルSHA-256は`validation_results.json`に記録しています。
