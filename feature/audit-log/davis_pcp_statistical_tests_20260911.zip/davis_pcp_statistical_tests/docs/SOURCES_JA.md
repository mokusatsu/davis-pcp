# 一次資料と期待値の出典

確認日：2026-09-11。ここに挙げる資料は定義や参照実装の根拠であり、本体の出力値を正当化するために逆算した資料ではない。文書のバージョンと、今回実行できた環境のライブラリバージョンは区別する。

## S01：NIST Statistical Reference Datasets—Univariate

原文最小引用：`Sample Standard Deviation (denom. = n-1)`

参照先：

```text
https://www.itl.nist.gov/div898/strd/univ/homepage.html
https://www.itl.nist.gov/div898/strd/univ/data/NumAcc1.dat
https://www.itl.nist.gov/div898/strd/univ/data/NumAcc2.dat
https://www.itl.nist.gov/div898/strd/univ/data/NumAcc3.dat
https://www.itl.nist.gov/div898/strd/univ/data/NumAcc4.dat
https://www.itl.nist.gov/div898/strd/univ/data/Mavro.dat
```

5つの公開データと認証済み平均・標準偏差を`fixtures/nist_univariate.json`へ整理した。入力は元の十進表記を文字列で保持し、テスト時にfloatへ変換する。認証値は文字列で別途保持する。原文DATの完全なバイトコピーではなく、数値部分をテスト用JSONへ正規化したもの。各データのURLをJSON内にも収録する。

|データ|n|認証平均|認証標準偏差|
|---|---:|---:|---:|
|NumAcc1|3|10000002|1|
|NumAcc2|1001|1.2|0.1|
|NumAcc3|1001|1000000.2|0.1|
|NumAcc4|1001|10000000.2|0.1|
|Mavro|50|2.00185600000000|0.000429123454003053|

NISTデータには自己相関等の認証値もあるが、時系列を対象外とするため、それらは今回のテスト対象にしない。5ケース通過をNISTの全データ・全統計量の合格と解釈しない。

## S02：R survey—svychisq

原文最小引用：`Rao-Scott second-order correction`

```text
https://r-survey.r-forge.r-project.org/pkgdown/docs/reference/svychisq.html
```

`statistic="F"`のRao–Scott第2次補正、Satterthwaite近似、設計自由度を参照する。一般化デザイン効果の単純無作為抽出分散は、Rが使用する観測割合を基準とする方式に合わせる。

実装：`oracles.rao_scott`と`reference/generate_R_reference.R`。前者は別式表現の多倍長オラクルであり、Rで生成した値ではない。後者のR直接実行は今回未確認。

## S03：R survey—svydesign

原文最小引用：`nest=TRUE`

```text
https://r-survey.r-forge.r-project.org/pkgdown/docs/reference/svydesign.html
```

PSU識別子の入れ子化、層化、FPC、単一PSU層の扱いを参照する。同じPSUコードを層を跨いで再利用する場合、Rの自由度式だけを取り出して無検証で適用してはならない。入力設計の妥当性も合わせて検査する。

今回のR参照スクリプトは一意PSUの設計を使用し、非certaintyのsingleton層は`survey.lonely.psu='fail'`とする。あらゆるsingleton補正方式の照合ではない。

## S04：statsmodels—Welch ANOVA

原文最小引用：`Variances are not assumed to be equal across samples.`

```text
https://www.statsmodels.org/stable/generated/statsmodels.stats.oneway.anova_oneway.html
```

`use_var='unequal', welch_correction=True`を採用。Welch ANOVAの独立数式オラクルを、別の実装でも検査するために使用した。今回の追加確認はローカルのstatsmodels 0.14.6で実行し、不等分散3データについてF値・分子／分母自由度・p値の一致を確認した。

証跡：`reports/welch_oracle_crosscheck.json`。再実行：`reference/crosscheck_welch_oracle.py`。通常のpytestにはstatsmodelsの依存を追加していない。

## S05：SciPy—chi2_contingency

原文最小引用：`Chi-square test of independence`

```text
https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.contingency.chi2_contingency.html
```

公開例`[[10,10,20],[20,20,20]]`を利用する。未補正Pearson χ²は25/9、自由度2。検定対象が通常PearsonのときにYates補正を勝手に混入させない。期待値は本体と同じSciPy呼び出しではなくFractionの周辺和計算とmpmathの裾確率で作成する。

## S06：SciPy—Fisher exact

原文最小引用：`two-sided`

```text
https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.fisher_exact.html
```

2×2表における条件付き超幾何分布と両側の確率順序を参照する。単純に片側p値を2倍する方法とは区別する。同じ周辺和の表を全列挙し、観測表以下の確率を持つ表の確率を有理数で加算する。

## S07：R stats—p.adjust

原文最小引用：`control the false discovery rate`

```text
https://stat.ethz.ch/R-manual/R-devel/library/stats/html/p.adjust.html
```

BHの補正値、順位の復元、同値、0と1を検査する。R直接比較では`p.adjust(method='BH')`を使う。任意の依存構造でBHが常にFDRを制御すると主張するものではなく、数値アルゴリズムの一致を検査する。

## S08：R stats—quantile

原文最小引用：`quantile`

```text
https://stat.ethz.ch/R-manual/R-devel/library/stats/html/quantile.html
```

type 7を採用し、0始まりの位置`h=(n-1)p`に対して隣接する順序統計量を線形補間する。異なる正当な分位点方式を誤りと呼ぶのではなく、このアプリが採用する方式を固定する。

## S09：SciPy—Kendall / Mann–Whitney

原文最小引用：`kendalltau`、`mannwhitneyu`

```text
https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.kendalltau.html
https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.mannwhitneyu.html
```

Kendallはτ-bの同順位補正を組合せの全列挙で再計算する。Mann–Whitneyの厳密分布照合は同順位のない小標本に限定し、同順位を含む場合の厳密分布と混同しない。

## S10：R stats—prcomp

原文最小引用：`arbitrary`

```text
https://stat.ethz.ch/R-manual/R-devel/library/stats/html/prcomp.html
```

固有ベクトル／回転行列の符号が任意であること、PCAの標準化と分散の意味を参照する。符号一致ではなく射影行列と再構成で比較する。今回、Rのprcomp自体を実行したわけではなく、PCA数値照合はNumPyの対称固有値分解を使用する。

## S11：R stats—glm

原文最小引用：`binomial`

```text
https://stat.ethz.ch/R-manual/R-devel/library/stats/html/glm.html
```

二項ロジスティック回帰の最尤推定という参照枠組みを使用する。2群それぞれ20人、成功5人と15人のデータでは、切片log(1/3)、傾きlog(9)、オッズ比9となり、最適化器を使わず期待値を求められる。対数尤度、観測情報行列、AIC/BICまで独立に計算する。Rのglmとの実行比較は今回含めていない。

## S12：scikit-learn—silhouette_samples

原文最小引用：`Silhouette Coefficient`

```text
https://scikit-learn.org/stable/modules/generated/sklearn.metrics.silhouette_samples.html
```

自クラスタ内平均距離a、最も近い他クラスタへの平均距離bから`(b-a)/max(a,b)`を再計算する。singletonは0という扱いを検査する。1クラスタしかない等の未定義条件を統計的に正当な0と認証しない。

## S13：R cluster—PAM

原文最小引用：`pam`

```text
https://stat.ethz.ch/R-manual/R-devel/library/cluster/html/pam.html
```

medoidへの非類似度和、BUILD/SWAPに対応する局所的な入替え条件を参照する。返された解の大域最適性は一般には要求しない。Rのpamとの実行比較ではなく、目的関数と全単一swap候補の独立検査を行う。

## S14：scikit-learn—GaussianMixture

原文最小引用：`GaussianMixture`

```text
https://scikit-learn.org/stable/modules/generated/sklearn.mixture.GaussianMixture.html
```

full共分散の1成分モデルで、標本数nで除した最尤共分散に明示したreg_covarを加え、正規対数尤度を直接計算する。パラメータ数はp+p(p+1)/2。AIC=-2logL+2k、BIC=-2logL+log(n)kを照合する。

## S15：NIST—外れ値・箱ひげの基準

原文最小引用：`Outliers`

```text
https://www.itl.nist.gov/div898/handbook/eda/section3/eda35h.htm
```

IQRに基づく外れ値基準を参照する。IQR1.5倍の境界は分位点type 7から独立計算する。MADによるrobust zは現行コードの1.4826係数と3.5閾値という採用定義を検査し、全ての母分布に対する普遍的判定閾値と説明しない。

## S16：R stats—ecdf（相違点の確認用）

原文最小引用：`ecdf`

```text
https://stat.ethz.ch/R-manual/R-devel/library/stats/html/ecdf.html
```

通常のECDFと、現行FEDFのHazen位置を区別するために参照した。ECDFの公式をFEDFの期待値として流用していない。

## 合成データと独自の受入条件

`survey_synthetic.csv`、不等分散群、直交LMGデータ、2群ロジスティックデータ、MA状態表、ランダムseed付き行列は、このパッケージ用の合成データである。政府の実調査個票、NISTの調査データ、R公式データのコピーであるかのようには扱わない。

Cohen's dの統一定義、非有限値の拒否／除外、空選択、未対応方式の明示、補完対象が全欠損の場合の扱いは、資料の認証値ではなく本システムの安全上の受入条件である。これらは`contract`または対応する仕様テストとして、認証値との比較とは区別した。
