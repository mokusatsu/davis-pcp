from __future__ import annotations
import importlib.metadata, json, os, sys, tempfile, hashlib, platform, shutil
from datetime import datetime, timezone
from pathlib import Path
import pytest

_RESULTS=[]
_MARKERS={}
_WORK=None
_TARGET=None

def pytest_addoption(parser):
    parser.addoption('--target-backend',action='store',required=True)
    parser.addoption('--kernel-only',action='store_true',default=False)
    parser.addoption('--with-r',action='store_true',default=False)
    parser.addoption('--result-json',action='store',default=None)

def pytest_configure(config):
    global _WORK
    root=Path(config.getoption('--target-backend')).resolve()
    if not (root/'app'/'config.py').is_file():raise pytest.UsageError(f'backend/app not found: {root}')
    # Set before importing ANY target module: never use a real project's workspace.
    _WORK=tempfile.TemporaryDirectory(prefix='davis-statistical-tests-')
    os.environ['DAVIS_PCP_WORKSPACE']=_WORK.name
    sys.path.insert(0,str(root))
    if 'app.config' in sys.modules:raise pytest.UsageError('app.config already imported; run in a fresh process for workspace isolation.')
    if config.getoption('--with-r') and shutil.which('Rscript') is None:
        raise pytest.UsageError('--with-r requires Rscript; R tests must not silently skip.')

def pytest_ignore_collect(collection_path,config):
    name=collection_path.name
    if config.getoption('--kernel-only') and name.startswith('test_full_'):return True
    if not config.getoption('--with-r') and name.startswith('test_r_'):return True
    return None

@pytest.fixture(scope='session')
def target(pytestconfig):
    global _TARGET
    from stats_tests.support import Target
    _TARGET=Target(Path(pytestconfig.getoption('--target-backend')).resolve(),pytestconfig.getoption('--kernel-only'))
    return _TARGET

@pytest.fixture(scope='session')
def pl():
    import polars
    return polars

def pytest_collection_modifyitems(items):
    for item in items:
        _MARKERS[item.nodeid]=sorted({m.name for m in item.iter_markers()})

def pytest_runtest_logreport(report):
    if report.when=='call' or report.failed:
        _RESULTS.append({'nodeid':report.nodeid,'phase':report.when,'outcome':report.outcome,
                        'duration':report.duration,'markers':_MARKERS.get(report.nodeid,[]),'detail':str(report.longrepr) if report.failed else None})

def pytest_sessionfinish(session,exitstatus):
    config=session.config; dest=config.getoption('--result-json')
    if dest:
        root=Path(config.getoption('--target-backend'))
        hashes={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((root/'app').rglob('*.py'))}
        versions={}
        for p in ['numpy','scipy','polars','pyarrow','scikit-learn','fastapi','pydantic','pytest','mpmath']:
            try:versions[p]=importlib.metadata.version(p)
            except importlib.metadata.PackageNotFoundError:versions[p]=None
        payload={'created_at_utc':datetime.now(timezone.utc).isoformat(),'thread_env':{k:os.environ.get(k) for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']},'exitstatus':int(exitstatus),'mode':'kernel-only' if config.getoption('--kernel-only') else 'full',
                 'live_R_requested':config.getoption('--with-r'),'python':sys.version,'platform':platform.platform(),
                 'versions':versions,'source_sha256':hashes,'results':_RESULTS,
                 'source_extracted_kernels':_TARGET.extracted if _TARGET else {},
                 'unexecuted_by_mode':['full_dataframe_and_API'] if config.getoption('--kernel-only') else []}
        if not config.getoption('--with-r'):payload['unexecuted_by_mode'].append('live_R_parity')
        path=Path(dest);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    if _WORK is not None:_WORK.cleanup()
