#!/usr/bin/env python3
"""Run in the application's Python environment. No automatic installation/network."""
from __future__ import annotations
import argparse, importlib.util, json, os, subprocess, sys, tempfile, zipfile
from pathlib import Path

HERE=Path(__file__).resolve().parent

def backend_at(path):
    for p in [path,path/'backend',path/'local'/'backend',path/'davis-pcp'/'backend']:
        if (p/'app'/'config.py').is_file():return p
    found=list(path.glob('*/backend/app/config.py'))
    if len(found)==1:return found[0].parents[1]
    raise ValueError('Specify the folder containing backend/app, backend itself, or the distribution ZIP.')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--target',required=True,type=Path)
    p.add_argument('--kernel-only',action='store_true',help='Explicit partial check; source-extract selected numerical functions. Not API certification.')
    p.add_argument('--with-r',action='store_true',help='Require live Rscript + survey parity; absence is an error.')
    p.add_argument('--out',type=Path,default=HERE/'reports'/'latest')
    p.add_argument('pytest_args',nargs=argparse.REMAINDER)
    a=p.parse_args(); tmp=None
    try:
        target=a.target.resolve()
        if target.is_file() and target.suffix.lower()=='.zip':
            tmp=tempfile.TemporaryDirectory(prefix='davis-target-'); dest=Path(tmp.name)
            with zipfile.ZipFile(target) as z:
                for info in z.infolist():
                    member=(dest/info.filename).resolve()
                    if not member.is_relative_to(dest):raise ValueError('Unsafe ZIP member')
                z.extractall(dest)
            target=dest
        backend=backend_at(target)
        deps=['pytest','numpy','scipy','mpmath','fastapi','sklearn']
        if not a.kernel_only:deps+=['polars','pyarrow','httpx']
        missing=[d for d in deps if importlib.util.find_spec(d) is None]
        if missing:
            print('PRECHECK FAILED: missing dependencies: '+', '.join(missing),file=sys.stderr)
            print('Use the existing application environment. Do not interpret this as a test pass.',file=sys.stderr)
            return 2
        out=a.out.resolve();out.mkdir(parents=True,exist_ok=True)
        cmd=[sys.executable,'-m','pytest','-c',str(HERE/'pytest.ini'),str(HERE/'stats_tests'),
             '--target-backend',str(backend),'--result-json',str(out/'results.json'),
             '--junitxml',str(out/'junit.xml')]
        if a.kernel_only:cmd+=['--kernel-only']
        if a.with_r:cmd+=['--with-r']
        extra=a.pytest_args[1:] if a.pytest_args[:1]==['--'] else a.pytest_args
        cmd+=extra
        # No shell invocation, explicit UTF-8. Log stdout/stderr without hiding failures.
        env=os.environ.copy();env['PYTHONIOENCODING']='utf-8'
        with (out/'console.txt').open('w',encoding='utf-8') as log:
            proc=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace',env=env,cwd=HERE)
            for line in proc.stdout:
                print(line,end='');log.write(line)
            status=proc.wait()
        print(f'Artifacts: {out}\nExit code: {status}')
        return status
    except (OSError,ValueError,zipfile.BadZipFile) as exc:
        print(f'PRECHECK FAILED: {exc}',file=sys.stderr);return 2
    finally:
        if tmp is not None:tmp.cleanup()

if __name__=='__main__':raise SystemExit(main())
