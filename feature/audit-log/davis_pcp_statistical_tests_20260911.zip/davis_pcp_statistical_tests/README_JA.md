# DAVIS-PCP 統計計算検証テストパッケージ

対象：`davis-pcp-local(2).zip`／作成日：2026-09-11

## 1. 内容と実行状況

アンケート分析を主用途とするDAVIS-PCPの統計計算を、認証済みデータ、独立した数式計算、Rの参照実装、入力変換に対する不変性で検証する追加テストです。時系列分析は対象外です。本体の修正パッチではありません。

|区分|ケース数|この環境での確認|
|---|---:|---|
|数値コア・独立参照値の検査|250|実行済み：240通過、10失敗|
|実Polarsによる集計・モデル・API等|134|収集・構文検査済み、実行未確認|
|Rとの直接照合|14|スクリプトを実装、R未導入のため未実行|
|合計|398|全件実行済みという意味ではありません|

ケース数はパラメータ展開後の数です。398種類の別アルゴリズムや398件の独立した不具合を意味しません。通常モードの384ケースはpytestで収集を確認しています。Rを含む398ケースの収集・実行は本環境では確認していません。

この配布ZIPには一般的な`tests/`やテストランナー設定がありません。そこで、既存コードを変更せずに外付けで実行するpytest形式にしました。`algorithms/mining/verification_test.py`は分析機能の本体であり、既存のテストスイートとして扱っていません。

最初に読むファイル：

- `docs/TEST_DESIGN_JA.md`：検証方針、統計上の定義、実装済み範囲と残りの検証課題。
- `docs/EXECUTION_REPORT_JA.md`：今回実行した結果、失敗した7論点、再現値と修正時の判断基準。
- `docs/SOURCES_JA.md`：一次資料、原文の短い引用、どの期待値に使ったか。

## 2. 通常実行：アプリのPython環境を使用

本パッケージを任意のフォルダに展開し、そのフォルダでコマンドを実行してください。アプリを実行している仮想環境を先に有効にします。既にアプリの依存関係が導入されていれば、追加するのはテスト用の依存だけです。

```powershell
python -m pip install -r requirements-test.txt
python run_statistical_tests.py --target "C:\dev\davis-pcp\local" --out "reports\local_full" -- -q
```

`--target`には、次のいずれかを指定できます。

```powershell
python run_statistical_tests.py --target "C:\dev\davis-pcp\local\backend" --out "reports\backend_full" -- -q
python run_statistical_tests.py --target "C:\Downloads\davis-pcp-local(2).zip" --out "reports\zip_full" -- -q
```

実際の設置場所に合わせてパスを変更してください。ZIP入力時は一時フォルダへ展開し、終了時に破棄します。ZIPの親フォルダへのパストラバーサルを拒否します。

まだアプリ環境を作成していない場合は、アプリに同梱された`backend/requirements.txt`に従って先に導入してください。本パッケージはアプリの依存バージョンを勝手に変更しません。テストランナーは自動インストールやネットワークアクセスを行いません。

### Rの参照実装も必須にする実行

Rの`Rscript`がPATHにあり、同じR環境に`survey`パッケージが導入されていることが前提です。

```powershell
Rscript -e "packageVersion('survey')"
python run_statistical_tests.py --target "C:\dev\davis-pcp\local" --with-r --out "reports\local_with_R" -- -q
```

このモードではRが利用できないとエラーにします。Rの比較を無言でskipして全件合格に見せる動作はありません。

R側では、同梱の合成調査データに対して次を別プロセスで実行します。

```r
survey::svydesign(...)
survey::svychisq(~r+c, design, statistic="F")
survey::svymean(~x+y, design)
stats::oneway.test(v~g, var.equal=FALSE)
stats::p.adjust(p, method="BH")
```

出力は`R_reference/`に17桁のTSV、Rの標準出力・標準エラー、`sessionInfo.txt`として保存します。既存本体の結果を「R期待値」として流用していません。現時点では、本パッケージにRで実測済みのgolden値は同梱していません。

## 3. 限定実行：数値コアのみ

```powershell
python run_statistical_tests.py --target "C:\dev\davis-pcp\local" --kernel-only --out "reports\kernel_only" -- -q
```

このモードでは、依存関係が揃っているモジュールは通常importします。Polarsに依存する一部のモジュールについてだけ、添付ソースの指定された関数本体をASTで抽出し、そのままコンパイルします。アプリ関数を別実装に置き換えるモックでも、Polarsを別の表計算エンジンに置き換える方法でもありません。

ただし、モジュール初期化、DataFrame前処理、API、保存・キャッシュ、ブラウザを通った検証ではありません。`results.json`には抽出した関数名とソースSHA-256、未実行の区分が明記されます。全件の品質判定に`--kernel-only`の結果だけを使わないでください。

この限定モードにもNumPy、SciPy、scikit-learn、FastAPI、pytest、mpmathが必要です。現在の抽出対象が外部の別関数や定数に依存するよう変更された場合は、`stats_tests/support.py`を更新するか通常モードで実行してください。

## 4. 結果の読み方

各実行で次が生成されます。

|出力|内容|
|---|---|
|`console.txt`|pytestの標準出力と失敗詳細|
|`junit.xml`|CI等で読めるテスト結果|
|`results.json`|ケース別成否、環境、対象ソースのSHA-256、抽出関数、除外した実行区分|
|`R_reference/`|`--with-r`の場合の参照値とRの実行記録|

通常の成功は終了コード0、テスト失敗は1、依存不足等の事前エラーは2です。pytest固有の収集・オプションエラー等はその終了コードをそのまま返します。

添付版には再現できた失敗があるため、現在のまま実行して終了コード1になること自体はランナーの故障ではありません。既知の失敗を`xfail`にして合格扱いにする設定は入れていません。

`contract`マーカーは「このシステムとして受け入れる統計上の安全条件」を示します。全てが普遍的な一意の統計定義というわけではありません。例えばCohen's dは、このパッケージでは探索機能と検証機能で同じpooled-n定義を採ることを受入条件としています。定義変更は説明・命名・期待値を一緒にレビューしてください。

対象を絞る例：

```powershell
python run_statistical_tests.py --target "C:\dev\davis-pcp\local" --out "reports\anova" -- -q -k "welch_anova"
python run_statistical_tests.py --target "C:\dev\davis-pcp\local" --out "reports\survey" -- -q -k "rao_scott or crosstab or ma_"
```

## 5. 安全性と再現性

対象アプリをimportする前に、一時フォルダを`DAVIS_PCP_WORKSPACE`へ設定します。APIテストのDatasetStoreもこの隔離領域を使用します。ユーザーの既存データ、既存ワークスペース、本体ソースを変更しません。APIはFastAPIのTestClientで検証し、外部公開ポートを開きません。

`reports/attachment_kernel/`は今回の実行記録です。`reports/zip_input_smoke/`はZIP入力経路でNISTの5ケースを再実行した記録で、別の5ケースが増えたわけではありません。`reports/manifest.json`には元ZIPのSHA-256と、検査した本体Pythonソース100ファイルが添付と一致していることを記録しました。

## 6. 現時点の限界

この環境にはPolars、PyArrow、Rがなく、依存取得もできなかったため、134件の通常統合テストと14件のRテストは未実行です。また、利用できたNumPy・SciPy・scikit-learn等のバージョンは添付の固定バージョンと一致していません。詳細は実行報告書にあります。

ブラウザ操作、Pyodide/WASMとネイティブPythonの一致、全機能のE2E、信頼区間の反復標本における被覆率は未検証です。統計式の数値一致は、調査設計や探索後推論の妥当性まで証明するものではありません。残る検証項目を隠さず`TEST_DESIGN_JA.md`に分けてあります。
