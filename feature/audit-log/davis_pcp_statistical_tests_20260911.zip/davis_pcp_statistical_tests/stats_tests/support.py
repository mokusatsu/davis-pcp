from __future__ import annotations
import ast, importlib, math, hashlib
from pathlib import Path
from typing import Any
from types import SimpleNamespace
import numpy as np
from scipy import stats

# Exact function bodies are compiled from the target for the explicit kernel-only mode.
# No fake Polars, no alternate implementation of the target, no swallowed exceptions.
KERNELS={
 'algorithms.summaries.core':['numeric_summary'],
 'algorithms.mining.subgroup':['benjamini_hochberg','label_effect','get_cramers_v_thresholds','_test_numeric','_test_ordinal'],
 'algorithms.mining.verification_test':['_weighted_mean_var','_unweighted_mean_var','_summary','_welch','_cohens_d','_kendall_tau','_safe_float','level_mask','_finite_mask'],
 'algorithms.summaries.crosstab':['adjusted_residual','significance_marker'],
}

class Target:
    def __init__(self, backend:Path, kernel_only=False):
        self.backend=backend; self.kernel_only=kernel_only; self.cache={}; self.extracted={}
    def module(self,name):
        if name in self.cache:return self.cache[name]
        if self.kernel_only and name in KERNELS:
            path=self.backend/'app'/Path(*name.split('.')).with_suffix('.py')
            source=path.read_text(encoding='utf-8-sig'); tree=ast.parse(source)
            selected=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in KERNELS[name]]
            assert {n.name for n in selected}==set(KERNELS[name]),f'Target API changed: {name}'
            new=ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0),*selected],type_ignores=[])
            ast.fix_missing_locations(new)
            namespace={'np':np,'stats':stats,'math':math,'Any':Any,'ALPHA':.05,'PERMUTATIONS':500}
            exec(compile(new,str(path),'exec'),namespace)
            module=SimpleNamespace(**{n.name:namespace[n.name] for n in selected})
            self.extracted[name]={'sha256':hashlib.sha256(source.encode()).hexdigest(),'functions':KERNELS[name]}
        else:module=importlib.import_module('app.'+name)
        self.cache[name]=module
        return module

def spec(name,scale='nominal',role='question',**kw):
    return {'columnId':name,'name':name,'label':name,'scaleType':scale,'role':role,
            'missingCodes':[],'valueLabels':{},**kw}

def codebook(*columns,**kw):
    return {'schemaVersion':1,'schemaRevision':1,'columns':list(columns),**kw}

def assert_nullable_close(actual,expected,**kw):
    import pytest
    if expected is None:assert actual is None
    else:assert actual == pytest.approx(expected,**kw)
