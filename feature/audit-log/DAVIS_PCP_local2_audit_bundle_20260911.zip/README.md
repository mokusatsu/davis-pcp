# DAVIS-PCP local(2) 監査・確定修正仕様・回帰テスト

対象：2026-09-11添付 `davis-pcp-local(2).zip`。アプリ本体の修正版ではありません。

## 内容

|ファイル|内容|
|---|---|
|AUDIT_REPORT.md|49修正単位。P0=5、P1=37、P2=7。実行再現と静的/条件付き確認を区別。|
|FIX_SPEC.md|固定版1.0。修正方法、API契約、未対応機能の停止範囲、実装順と受入条件。|
|backend/tests/survey_audit/|既存形式に合わせたunittest.TestCase、合成fixture、JSON/JUnit出力runner。|
|TEST_RESULTS.md|70テストの個別結果・対応する修正ID。|
|evidence/|合成データによる現版の実行結果とログ。|
|findings.json / source_index.json|機械可読の指摘一覧、Pythonソースのhashとシンボル行範囲。|
|SOURCES.md|一次資料と既存テスト形式の出典。|
|reference/|Rao–Scottの独立oracleを作る補助Rスクリプト。今回R環境では未実行。|
|package_manifest.json|納品ファイルのサイズ/SHA-256。署名や出所認証ではない。|

## 最初に読む箇所

AUDIT_REPORTの結論とP0、次にFIX_SPECの「今回の修正版の範囲」「実装順と完了条件」を読んでください。修正時はコードの現状に合わせて期待値を変えず、FIX_SPECを基準にします。

## テストの配置

納品ZIPの `backend/tests/survey_audit` ディレクトリを、対象プロジェクトの同じ場所へ追加します。アプリや既存テストを上書きしません。例：

```text
local/
  backend/
    app/
    requirements.txt
    tests/
      survey_audit/
        audit_support.py
        test_survey_contracts.py
        test_edge_contracts.py
        run_audit.py
```

`app`がimportできるプロジェクト用Python環境（添付版のrequirementsを満たす環境）を使います。テスト用にpytest等を追加する必要はありません。

## 実行

プロジェクトルート（backendの一つ上）で、既存テストと同じunittest discover方式で実行します。

```powershell
python -m unittest discover -s backend/tests/survey_audit -p "test_*.py" -v
```

JSONとJUnit XMLを残す場合：

```powershell
python backend/tests/survey_audit/run_audit.py --output audit-results
```

ローカル配布のvenvを指定する例：

```powershell
.\.venv\Scripts\python.exe backend\tests\survey_audit\run_audit.py --output audit-results
```

出力は `audit-results/test-results.json` と `audit-results/junit.xml`。FAIL/ERRORが1件でもあればrunnerは終了コード1です。現版で失敗するのが正常な検出結果であり、失敗を0件に見せるためのskipやexpectedFailureを使っていません。

## 安全なworkspace

テストは独立した新しいPythonプロセスで実行します。実データではなく合成fixtureのみを用い、`tempfile.mkdtemp()`で専用workspaceを作ります。既存のDAVIS_PCP_WORKSPACEをテストに流用しません。終了時に専用workspaceだけを削除します。

同じプロセスで製品APIを先にimport済みの場合は安全のため停止します。アプリ稼働プロセスからimportして呼ばず、上の専用discover/runnerコマンドを使ってください。CIでも独立したジョブ/プロセスとして登録します。テストを全backendテストと同一プロセスへ無条件に混ぜる前提ではありません。

パッケージ移送の試験は、メモリ内UploadFileを使い実import関数を直接呼びます。現在のそのコルーチンはメモリ読込み以外に非同期待機をしません。将来非同期I/Oを導入した場合、helperが明示停止するので、そのケースをIsolatedAsyncioTestCaseへ移行します。例外を成功に変換するadapterではありません。

## 今回の実行結果

70件：PASS=17 / FAIL=53 / ERROR=0 / SKIP=0。

指定ネイティブ依存をネットワーク制約で取得できず、現版のアプリソースをPyodide上で実行しました。借用したのは過去静的配布の実行依存だけで、旧版アプリの結果を混ぜていません。thread/Parquet I/OのWASM用adapterと依存バージョン差の詳細はAUDIT_REPORTにあります。

この結果はWindows・指定依存版・ブラウザE2Eの合格を意味しません。特にRao–ScottのR oracle全体照合は未実施です。FIX_SPECの追加受入を省略しないでください。

## 補助のR参照値生成

Rとsurveyパッケージがある検証環境でのみ、次を使います。スクリプト内で依存の自動インストールはしません。

```text
Rscript reference/generate_rao_scott_reference.R rao_scott_reference.json
```

出力JSONにR/surveyの版とfixtureごとのF/自由度/pを保存します。これはPythonの70件とは別の参照値生成で、今回の通過件数には含めていません。fixture範囲は基本表・層・PSU・倍率不変であり、FIX_SPECの全受入シナリオを単独で網羅するものではありません。

## 修正時の注意

数式やAPI内部構造の変更に応じて呼出しのadapterを移すことはできますが、期待する解析値、対象人数、原本内容、拒否条件を緩和してはいけません。新しい不具合を見つけた場合は新規IDと再現fixtureを追加します。70件全通過だけを全機能の保証と扱わず、未実施のGUI・Windows・R参照試験も実施します。
