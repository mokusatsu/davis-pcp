# DAVIS-PCP local(2)：アンケートEDA監査報告

評価日：2026-09-11（日本時間）  
対象：`davis-pcp-local(2).zip`  
SHA-256：`4965801943604c16e0eeb51017f00aec9f5dafe18ee3ce1a7c7caa74dfe37673`  
現配布フロント：`frontend/dist/assets/index-5mARUBaL.js`  
修正仕様：同梱`FIX_SPEC.md`、固定版1.0。アプリの修正コードではなく、監査・確定仕様・回帰テストの納品である。

## 1. 結論

この版は改善があるが、実回答の分析結果を確定する用途にはまだ使わないことを推奨する。特に原本の喪失、欠損コードを使った補完、探索と検証での得点反転、感度分析の母数・効果の取り違えが残る。見た目のエラーではなく、正常応答のまま数値や意味が変わる経路を優先した。

修正単位を49件（P0=5、P1=37、P2=7）に整理した。複数機能に共通する原因を含むため、独立した根本原因の総数でも全不具合の総数でもない。静的確認・条件付き契約試験を実行確認と区別する。P0/P1/P2は本用途の修正順でありCVSSではない。

- P0：原本や解析結果の意味を壊す。修正まで当該操作の利用停止。
- P1：主要な集計・検証・設定・選択の契約違反。実用前に修正。
- P2：限定条件、表示意味、利便性、配布の問題。

## 2. 実施した確認と限界

ZIPを展開して現版`backend/app`を使用し、合成データでAPI/分析関数/原本・履歴・パッケージを検査した。過去版のアプリを代理実行したものではない。独立の期待値として、加重相関、層別分散、群差、t区間を小規模fixtureから計算した。HTTPX ASGIを通した取込・パッケージ復元・静的ファイル配信も別probeで確認した。

このZIPには既存のテスト一式がない。Libraryにある既存`backend/tests/m0/test_api.py`と`test_ordering.py`の`unittest.TestCase`、`test_*`、通常assertion形式に合わせた。今回追加の自動回帰テストは70件、PASS=17、FAIL=53、ERROR=0、SKIP=0。FAILには仕様として固定した安全な動作への未対応も含む。「53個の独立不具合が発見された」という意味ではない。既知不具合をexpectedFailure/skipにせず、修正後に成功すべき条件として失敗させた。

### 実行環境

指定ネイティブ依存を取得できなかったため、Libraryにある旧静的配布から実行依存だけを借り、現版ソースをPyodideで実行した。外部取得失敗はDNS/ネットワークの制約であり、指定バージョンが存在しないと判定したのではない。

|項目|現版requirements|実行環境|
|---|---|---|
|Python|ランチャー判定|3.12.7 / Pyodide 0.27.7|
|FastAPI|0.139.2|0.141.1|
|Pydantic|2.13.4|2.10.5|
|NumPy|2.4.6|2.0.2|
|SciPy|1.18.0|1.14.1|
|scikit-learn|1.9.0|1.6.1|
|Polars|1.43.2|1.18.0|
|PyArrow|25.0.1|18.1.0|
|HTTPX|0.28.1|0.28.1|

WASM用のthreadpool→同一loop adapter、PolarsのParquet読書き→Arrow（辞書変換）adapterを使用した。アプリの数式・分岐・入力条件は置換していない。これらのadapterで検証できない並行処理・native I/O・性能・Windowsパスは確認済みに含めない。パッケージのunittestはメモリ内UploadFileで実コルーチンを完了させる直接API試験であり、HTTPルーティングの試験とは区別する。

PCP描画・ブラッシング・軸ドラッグ・ダウンロード・ブラウザ永続化・WindowsランチャーのE2Eは実施していない。フロントは現配布のminified JSを構文整形して追跡した。配布元のTS/TSX、package.json、source mapはない。R surveyとの全体Rao–Scott oracle一致、区間被覆率・検定サイズのシミュレーションも未実施。

時系列、画像、予測サービス運用、原典DAVIS全機能の復元は不足扱いしない。全データEDAは正当な利用であり、すべての探索に独立標本を要求しない。「独立検証」や「95%区間」を表示するなら実装内容がその意味に一致しなければならない、という評価である。

## 3. 今回、通過した改善

前回の指摘をそのまま再掲していない。少なくとも以下は現版の合成fixtureで通過した。

|項目|現版の確認結果|
|---|---|
|履歴|Undo後の値・平均・補完マスクが一致。2回Undoで補完が復活しない。計算列Undoで列とコードブックが戻る。|
|削除|DatasetStore配下の原本・現在値・マスク・revisionファイルを削除。すべての派生保存領域の完全消去を保証した意味ではない。|
|ウェイト|重み列自身の欠損コードを除外。frequencyの小数はクロス表で拒否。survey既定p/星を抑止。重み1→100でRao–Scott p/割合が不変。weights-only推測に近似表示。|
|複数回答|w=9,1の完全回答2人で加重回答者比率90%/10%。|
|scope|active=[]、sampled=[]は0件を保持。samplingのunknown IDとsummaryの古いrevisionを拒否。|
|尺度・補完|明示categoryOrderで行順不変。整数列への小数定数は黙って切り捨てず拒否する。|
|決定木|根ノードのクラス人数9/11、計20が一致。旧「割合を整数化して0/1」の再現ではない。|

これらは限定fixtureの通過であり、その機能全域の完了判定ではない。特に通常summaryと他APIの共通化、原本・履歴のパッケージ移送は別経路として残っている。

## 4. 修正一覧

|ID|優先度|指摘|確認区分|
|---|---|---|---|
|AV01|P1|順序尺度の得点が対象行に依存する|現版実行＋ソース照合|
|AV02|P1|逆転項目に3系統の得点変換が存在し平均が一致しない|現版実行＋ソース照合|
|AV03|P1|数値変換できない文字がカテゴリ順位として加重平均に混入する|現版実行＋ソース照合|
|AV04|P1|旧schema更新が型付きコードブックを破壊する|現版実行＋ソース照合|
|AV05|P2|先頭ゼロのコードを比率尺度として自動確定する|現版実行＋ソース照合|
|AV06|P1|FEDF列省略時とQQで欠損コードの除外が抜ける|現版実行＋ソース照合|
|AV07|P2|同値回答者が異なるFEDF座標になる|現版実行＋ソース照合|
|AV08|P2|定数列に「正規」と判定する|現版実行＋ソース照合|
|AV09|P1|LOESSが逆転前の値で描かれる|現版実行＋ソース照合|
|W01|P1|ウェイト未指定と「なし」がAPI間で異なる|現版実行＋ソース照合|
|W02|P1|frequencyの整数性をsummaryが検証しない|現版実行＋ソース照合|
|W03|P1|表示用丸めにより微小な正の重みがゼロ扱いになる|現版実行＋ソース照合|
|W04|P1|加重済み応答内の相関だけ非加重になる|現版実行＋ソース照合|
|W05|P1|調査診断が表の母数とスコープ母数を混在させる|現版実行＋ソース照合|
|W07|P1|MAが対象外の不正重みで非加重へフォールバックする|現版実行＋ソース照合|
|W09|P1|inference=noneでもセルの有意マーカーを返す|現版実行＋ソース照合|
|SD01|P1|PSUを省略すると指定した層まで破棄される|現版実行＋ソース照合|
|SD02|P1|層内PSU番号の再利用で自由度が変わる|現版実行＋ソース照合|
|SD03|P1|設計変数の欠損を実在PSUとして扱う|現版実行＋ソース照合|
|SD04|P1|単独PSU層の分散を0にして通常の推測成功を返す|現版実行＋ソース照合|
|SD05|P1|未検証のFPCが分散を0へ切り捨てる|現版実行＋ソース照合|
|SD06|P1|ウェイト変更後も旧ウェイトに結び付いた設計が残る|現版実行＋ソース照合|
|SD07|P1|フィルタ後の設計再作成でドメイン分散の契約が不足する|静的確認・数値oracle照合未実施|
|IM01|P0|欠損コードをドナーとして使い補完値を汚染する|現版実行＋ソース照合|
|IM02|P1|補完プレビューのハッシュが設問の意味変更を検出しない|現版実行＋ソース照合|
|PK01|P0|予約列名の衝突で取り込んだ原データが失われる|現版実行＋ソース照合|
|PK02|P0|パッケージ復元が原本を補完後の現在値に取り替える|現版実行＋ソース照合|
|PK03|P1|パッケージ内のdatasetIdと履歴カーソルが移行されない|現版実行＋ソース照合|
|PK04|P1|manifestの検証対象を空にしても復元成功する|現版実行＋ソース照合|
|PK05|P1|コードブックJSONの往復で重み・調査設計が復元されない|現版実行＋ソース照合|
|V01|P1|探索後の分割を独立した検証として表示する|現版実行＋ソース照合|
|V02|P0|探索と検証で逆転項目の向きが反対になる|現版実行＋ソース照合|
|V03|P2|5-foldの各効果量がnullになる|現版実行＋ソース照合|
|V04|P1|候補固定後のコードブック変更を失効させない|現版実行＋ソース照合|
|V05|P1|多重比較補正の指定名と計算が一致しない|現版実行＋ソース照合|
|V06|P1|modern候補の独立データ検証から条件列が落ちる|現版実行＋ソース照合|
|V07|P1|カテゴリ目的のmodern候補を平均差として固定する|候補変換・評価関数の契約試験（modern探索→UIの全経路は未実施）|
|SN01|P0|感度分析が欠損・逆転前の値で正反対の効果を返す|現版実行＋ソース照合|
|SN02|P1|群差の条件欠落が全体平均へ黙って置き換わる|現版実行＋ソース照合|
|SN03|P1|KPIの区間がWelchと名乗りながら固定1.96で計算される|現版実行＋ソース照合|
|CTX01|P2|空のexplicit scopeだけ不正入力になる|現版実行＋ソース照合|
|CTX02|P1|範囲選択が実在しないrowIdを返す|現版実行＋ソース照合|
|CTX04|P1|復元抽出の重複回数が後続集計で消える|現版実行＋ソース照合|
|CTX05|P1|KDAが対象行と世代指定を無視する|現版実行＋ソース照合|
|CTX06|P2|大きなデータを減らすsampling API自身が入口で拒否する|現版実行＋ソース照合|
|UI01|P1|大きなクロス表セルの再取得で表示時のscopeが落ちる|現配布JSの静的確認＋共通scopeコード照合（ブラウザ未実施）|
|SE01|P1|静的配信が公開フォルダの外へ到達する|現版実行＋ソース照合|
|DEP01|P2|ランチャーが更新後の依存変更と空白パスに弱い|静的確認（Windows未実施）|
|AV10|P1|LOESSの「95%区間」に対応する分散計算が保証されない|数式・名称の静的照合（区間被覆率のシミュレーションは未実施）|

## 5. 個別の再現・影響・確定修正

### AV01 [P1] 順序尺度の得点が対象行に依存する

確認区分：現版実行＋ソース照合。

再現条件：x=[5,1,3]をordinal、categoryOrder空にして、全件とraw=1の1行だけを比較する。

現版の結果：全件得点[1,2,3]ではraw=1が2点、同じ行を単独抽出すると1点になる。固定したcategoryOrderを与える試験は通過。

確定修正：数値コードの順序を全データから一度だけ昇順で確定・永続化する。分析subsetでは再推定しない。文字列のordinalで順序未指定は422。明示的scoreMapがなければ固定順の1始まり順位を得点とする。

根拠コード：`backend/app/domain/codebook_adapter.py::get_ordered_categories,analysis_series`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/01_core.json#ordinal`。

自動回帰：

- `test_survey_contracts.AnalysisValueTests.test_AV01_declared_order_has_same_scores_after_row_shuffle`：現版PASS。
- `test_survey_contracts.AnalysisValueTests.test_AV01_ordinal_score_is_subset_invariant`：現版FAIL。

---

### AV02 [P1] 逆転項目に3系統の得点変換が存在し平均が一致しない

確認区分：現版実行＋ソース照合。

再現条件：x=[1,3,9]、1～5のカテゴリ領域、逆転指定、全重み1。

現版の結果：通常平均1.6666667、補助平均5.67、加重平均5.6667。通常経路は9を-3へ変換し、別経路は観測最大9へ逆転上限を拡大する。範囲外値の扱いも未統一。

確定修正：宣言された離散領域1～5で9はinvalid_valueとして除外し、invalidCountへ記録。逆転は常に6-x。全経路は同一分析値を使用。この固定契約では有効2人、平均・加重平均とも4。範囲外を許容する設問は宣言領域を明示変更する。

根拠コード：`backend/app/algorithms/summaries/core.py::summarize; domain/codebook_adapter.py`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/01_core.json#reverse_out_of_domain`。

自動回帰：

- `test_survey_contracts.AnalysisValueTests.test_AV02_out_of_domain_is_not_used_to_expand_reverse_bounds`：現版FAIL。
- `test_survey_contracts.AnalysisValueTests.test_AV02_reversed_identity_weights_match`：現版FAIL。

---

### AV03 [P1] 数値変換できない文字がカテゴリ順位として加重平均に混入する

確認区分：現版実行＋ソース照合。

再現条件：x=["1","oops","3"]をratioとし、w=[1,1,1]で集計。

現版の結果：主平均2、有効count=2に対し、denominators.valid=3、補助平均2.33、加重平均2.3333。

確定修正：数値parse失敗を名義順位へ救済しない。invalid_valueへ分類し、主統計・補助統計・加重統計の有効者集合を統一。有効2、各平均2、除外理由invalidを1件返す。

根拠コード：`backend/app/algorithms/summaries/core.py; domain/codebook_adapter.py`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/01_core.json#invalid_numeric_weight`。

自動回帰：

- `test_survey_contracts.AnalysisValueTests.test_AV03_numeric_garbage_not_scored_as_category_rank`：現版FAIL。
- `test_survey_contracts.AnalysisValueTests.test_AV03_numeric_valid_denominator_matches_numeric_count`：現版FAIL。

---

### AV04 [P1] 旧schema更新が型付きコードブックを破壊する

確認区分：現版実行＋ソース照合。

再現条件：旧PATCH schemaへcategoryOrder="alphabetical"、role="categorical_axis"を渡す。

現版の結果：成功応答し、文字列のcategoryOrderと非正規roleを保存。分布にa,l,p,h等の架空カテゴリを生成する。

確定修正：旧APIからも正規Codebook更新サービスだけを通す。本入力は422で拒否し書込みなし。並べ替え方法はcategorySortとして別項目化、具体的categoryOrder配列と混同しない。

根拠コード：`backend/app/api/datasets.py::patch_schema,_patch_schema`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/03_state_design.json#schema_patch / schema_after / schema_summary`。

自動回帰：

- `test_survey_contracts.AnalysisValueTests.test_AV04_legacy_schema_cannot_store_invalid_role_and_order_type`：現版FAIL。

---

### AV05 [P2] 先頭ゼロのコードを比率尺度として自動確定する

確認区分：現版実行＋ソース照合。

再現条件：code=["001","002","003"]を取り込む。

現版の結果：文字列値は保持するが、scaleType=ratioになり、コードに平均が付く。入力値消失とは区別する。

確定修正：先頭ゼロ付き数字文字列はnominalを初期値に固定し、code候補を表示する。数値化は利用者の明示変換のみ。

根拠コード：`backend/app/services/import_service.py`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/02_workflows.json#leading_zero`。

自動回帰：

- `test_survey_contracts.AnalysisValueTests.test_AV05_leading_zero_codes_default_to_nominal`：現版FAIL。

---

### AV06 [P1] FEDF列省略時とQQで欠損コードの除外が抜ける

確認区分：現版実行＋ソース照合。

再現条件：x=[1,2,3,4,99]、99を欠損としてFEDFのcolumns有無とQQを比較。

現版の結果：FEDF columns=[x]では最大4・有効4、columns省略では最大99・有効5。QQも99を含む。

確定修正：列集合を先に解決し、その集合に共通AnalysisFrameを適用する。QQも同じ欠損・invalid・得点変換を使用する。生値表示が必要なら別の明示モードに分ける。

根拠コード：`backend/app/api/distribution.py::get_fedf; api/summaries.py::qqplot_summary`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/01_core.json#fedf_explicit / fedf_omitted / qq_missing`。

自動回帰：

- `test_survey_contracts.AnalysisValueTests.test_AV06_fedf_omitted_columns_same_as_explicit`：現版FAIL。
- `test_survey_contracts.AnalysisValueTests.test_AV06_qqplot_excludes_codebook_missing`：現版FAIL。

---

### AV07 [P2] 同値回答者が異なるFEDF座標になる

確認区分：現版実行＋ソース照合。

再現条件：x=[1,1,1,1,3]でFEDFを作成。

現版の結果：同じ1の4人に4種類のquantileが付く。行の並びで同じ回答の座標が変わり得る。

確定修正：同値には平均順位を使い、p=(averageRank-0.5)/n、folded=1-2*abs(p-0.5)を固定。重なり回避のjitterは描画だけの別設定とし、選択・集計の値には使わない。これは表示意味の修正であり、同値へ連番順位を割り当てる方式そのものを一般論として誤りと断言しない。

根拠コード：`backend/app/algorithms/distribution/fedf.py::compute_fedf`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/unittest/test-results.json#test_AV07_equal_answers_have_equal_fedf_quantiles`。

自動回帰：

- `test_edge_contracts.EdgeContractTests.test_AV07_equal_answers_have_equal_fedf_quantiles`：現版FAIL。

---

### AV08 [P2] 定数列に「正規」と判定する

確認区分：現版実行＋ソース照合。

再現条件：x=[1,1,1,1,1]をQQで確認。

現版の結果：pValue=1.0、isNormalAlpha05=true。定数列という検定不適用の状態を正規性の証拠に見せる。

確定修正：有効N不足、分散ゼロ、数値不安定はnormality status=unavailable、pと判定をnull。一般の非棄却も「正規性を棄却しない」と表示し「正規である」と断言しない。

根拠コード：`backend/app/api/summaries.py::qqplot_summary; algorithms/summaries/qqplot.py`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/01_core.json#qq_constant; unittest/test-results.json#test_AV08_constant_qq_does_not_claim_normality`。

自動回帰：

- `test_edge_contracts.EdgeContractTests.test_AV08_constant_qq_does_not_claim_normality`：現版FAIL。

---

### AV09 [P1] LOESSが逆転前の値で描かれる

確認区分：現版実行＋ソース照合。

再現条件：x=q=[1,2,3,4,5]、qを1～5逆転にしてLOESS。

現版の結果：集計上のq得点は[5,4,3,2,1]なのにLOESSのyは[1,2,3,4,5]。欠損マスクだけを適用し分析値変換がない。

確定修正：LOESSにも共通の数値AnalysisFrameを渡す。表示・曲線・残差・外れ値選択は同じyを使用。生値モードを残す場合は値空間をAPIと画面に明示する。

根拠コード：`backend/app/api/regression.py::get_loess`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/04_delivery_edges.json#loess_reverse`。

自動回帰：

- `test_edge_contracts.EdgeContractTests.test_AV09_loess_uses_reversed_scores`：現版FAIL。

---

### W01 [P1] ウェイト未指定と「なし」がAPI間で異なる

確認区分：現版実行＋ソース照合。

再現条件：コードブックにsurvey weightを保存し、weightColumnを省略またはnullで送る。

現版の結果：通常summaryは非加重、クロス表は保存済みweightを自動適用。画面のallowClear「ウェイトなし」もundefined送信なのでクロス表で解除できない。画面操作自体は未実施。

確定修正：全APIにweightMode=dataset|none|columnを導入する。既定dataset、明示noneだけ無効化。旧省略/nullはdatasetに移行。UIの解除は必ずnone。columnモードは列とweightTypeを明示し、保存済み設計との整合性を検査。

根拠コード：`backend/app/api/summaries.py::_summaries,crosstab_summary; frontend/dist/assets/index-5mARUBaL.js`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/01_core.json#default_weight_summary / default_weight_crosstab`。

自動回帰：

- `test_survey_contracts.WeightTests.test_W01_declared_weight_default_is_identical_across_endpoints`：現版FAIL。

---

### W02 [P1] frequencyの整数性をsummaryが検証しない

確認区分：現版実行＋ソース照合。

再現条件：frequencyとしてw=1.5を6人へ適用。

現版の結果：クロス表は422 WEIGHT_FREQUENCY_NONINTEGER、通常summaryは加重として受理。

確定修正：weight解決・値検証・意味検証を共通処理へ統一。frequencyは有限の非負整数、surveyは有限の非負実数。小数を丸めてfrequencyにしない。MA・相関も同一契約。

根拠コード：`backend/app/api/summaries.py::_summaries,crosstab_summary; domain/survey_weight.py`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/01_core.json#fractional_frequency_summary / fractional_frequency_crosstab`。

自動回帰：

- `test_survey_contracts.WeightTests.test_W02_frequency_fractions_rejected_in_crosstab`：現版PASS。
- `test_survey_contracts.WeightTests.test_W02_frequency_fractions_rejected_in_summary`：現版FAIL。

---

### W03 [P1] 表示用丸めにより微小な正の重みがゼロ扱いになる

確認区分：現版実行＋ソース照合。

再現条件：surveyで全6人w=1e-7を指定。

現版の結果：合計を小数4桁へ丸めて0とし、WEIGHT_NO_POSITIVEを返す。重み1と100の倍率不変試験は通るが、微小倍率で破れる。

確定修正：計算・分岐・保存に表示丸めを使わない。内部はfloat64、必要に応じ計算安定化用スケーリングを実施。生のweightSumを別保持。正の総重みがある限り桁丸めで全件なしにしない。

根拠コード：`backend/app/api/summaries.py::_summaries,crosstab_summary; api/multi_response.py`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/01_core.json#tiny_weights`。

自動回帰：

- `test_survey_contracts.WeightTests.test_W03_rescaling_does_not_change_survey_p_or_percentages`：現版PASS。
- `test_survey_contracts.WeightTests.test_W03_small_positive_survey_weights_are_not_zero`：現版FAIL。

---

### W04 [P1] 加重済み応答内の相関だけ非加重になる

確認区分：現版実行＋ソース照合。

再現条件：x=[0,1,2,10]、y=[0,1,9,1]、w=[1,1,1,100]。

現版の結果：weightApplied=trueなのにr=-0.1173。独立計算した加重Pearson相関は-0.4210178。

確定修正：相関はペアごとの有効値・正の重みで加重共分散を計算。結果ごとにweighted、pairwiseN、pairwiseWeightSumを返す。未対応の手法を応答全体の加重バッジで包まない。

根拠コード：`backend/app/api/summaries.py::_summaries; algorithms/summaries/core.py::correlation_matrix_df`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/01_core.json#correlation`。

自動回帰：

- `test_survey_contracts.WeightTests.test_W04_weighted_correlation_uses_pairwise_weights`：現版FAIL。

---

### W05 [P1] 調査診断が表の母数とスコープ母数を混在させる

確認区分：現版実行＋ソース照合。

再現条件：有効な2×2の6人w=1に、片方が欠損の1人w=100を加える。

現版の結果：表の合計6、診断unweightedN=6、weightSum=106、positiveWeightN=7、Kish ESS=1.1229。別母数を1ブロック内に混ぜる。

確定修正：weightDiagnosticsは当該表の有効値・正重み集合に統一。本例はsum=6、positiveN=6、Kish=6。スコープ全体はscopeWeightDiagnosticsとして別ブロック・名称で保存。

根拠コード：`backend/app/algorithms/summaries/crosstab.py::compute_crosstab; algorithms/survey/diagnostics.py`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/01_core.json#diagnostic_denominators`。

自動回帰：

- `test_survey_contracts.WeightTests.test_W05_effective_weight_diagnostics_match_table_base`：現版FAIL。

---

### W07 [P1] MAが対象外の不正重みで非加重へフォールバックする

確認区分：現版実行＋ソース照合。

再現条件：MA回答o1/o2、w=[9,1,-1]。最初の2人のみをrowIdsで集計。

現版の結果：対象内なら90%/10%のはずが、対象外の-1を検出してunsupportedの50%/50%へ変更。警告はあり、完全に黙殺する旧実装とは異なる。基本の2人加重は通過。

確定修正：先に解析scopeを確定し、その対象の重みを検証。対象外の不正値で対象内結果を変更しない。対象内不正重みは422で停止し、非加重値へ自動代替しない。

根拠コード：`backend/app/api/multi_response.py::summarize_multi_response`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/02_workflows.json#ma_outside_invalid / ma_weighted`。

自動回帰：

- `test_survey_contracts.WeightTests.test_W07_ma_invalid_weight_outside_scope_does_not_disable_weighting`：現版FAIL。
- `test_survey_contracts.WeightTests.test_W07_ma_weighted_numerator_and_denominator`：現版PASS。

---

### W09 [P1] inference=noneでもセルの有意マーカーを返す

確認区分：現版実行＋ソース照合。

再現条件：非加重の完全分離2×2表でinference=none。

現版の結果：全体pはnullだがセルsignificanceは残る。検定OFFが出力全体に適用されていない。

確定修正：inference=noneでは全体p、セルp/調整p、星をすべてnull。記述残差はdescriptiveと明示してのみ表示可。surveyはRao–Scottを選んでも通常セル星を出さない。

根拠コード：`backend/app/algorithms/summaries/crosstab.py::compute_crosstab`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/unittest/test-results.json#test_W09_inference_none_disables_cell_stars_too`。

自動回帰：

- `test_edge_contracts.EdgeContractTests.test_W09_inference_none_disables_cell_stars_too`：現版FAIL。

---

### SD01 [P1] PSUを省略すると指定した層まで破棄される

確認区分：現版実行＋ソース照合。

再現条件：4人、層[s1,s1,s2,s2]、PSU省略、線形化値[0,2,10,12]。

現版の結果：単一層に変更されdf=3。合計推定の分散は138.6667になる。指定どおりの2層・独立行PSUではdf=2、分散4+4=8。

確定修正：PSU省略は各行をPSUにするだけで、指定層は保持。完全に設計が不明な場合と「層既知・PSUは独立行近似」を区別して返す。[R1]

根拠コード：`backend/app/algorithms/survey/design.py::build_design; algorithms/survey/covariance.py::linearized_total_covariance`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/01_core.json#design_strata_only; 03_state_design.json#strata_covariance`。

自動回帰：

- `test_survey_contracts.SurveyDesignTests.test_SD01_strata_not_discarded_without_explicit_psu`：現版FAIL。
- `test_survey_contracts.SurveyDesignTests.test_SD01_stratified_covariance_independent_oracle`：現版FAIL。

---

### SD02 [P1] 層内PSU番号の再利用で自由度が変わる

確認区分：現版実行＋ソース照合。

再現条件：2層それぞれにPSU=1,2を持つ同一設計で、PSU名だけを層付きに変更。

現版の結果：局所番号ではPSU2個・df0、層付き番号なら4個・df2。共分散は層別に集約しているのに自由度だけ全体の生IDを数える。

確定修正：PSU識別子は内部で(stratumId,psuId)の組として正規化。Rのnest=TRUE相当を仕様として採用し、ラベルの付け替えで統計を変えない。層をまたぐ同一PSUという交差設計を明示した入力は今回未対応として拒否する。[R1]

根拠コード：`backend/app/algorithms/survey/design.py::number_of_psus,design_df`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/01_core.json#design_nested / design_unique`。

自動回帰：

- `test_survey_contracts.SurveyDesignTests.test_SD02_nested_local_psu_ids_do_not_change_df`：現版FAIL。

---

### SD03 [P1] 設計変数の欠損を実在PSUとして扱う

確認区分：現版実行＋ソース照合。

再現条件：PSU列にNoneを入れて設計を構築。

現版の結果：文字列"None"というクラスタとして受理し、provided/approximate=falseで推測へ流せる。設計列のmissingCodesも共通アダプタを通らない。

確定修正：層・PSUのNone、欠損コード、未定義値を検証し422。黙って文字列化・除外・新クラスタ生成しない。空文字を許すID仕様にもせず、正規化を一箇所に固定。[R1]

根拠コード：`backend/app/algorithms/survey/design.py::build_design; api/summaries.py::crosstab_summary`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/01_core.json#design_missing_psu`。

自動回帰：

- `test_survey_contracts.SurveyDesignTests.test_SD03_missing_psu_is_not_a_literal_cluster`：現版FAIL。

---

### SD04 [P1] 単独PSU層の分散を0にして通常の推測成功を返す

確認区分：現版実行＋ソース照合。

再現条件：2層・計3PSUで、1層が単独PSUのクロス表。

現版の結果：単独層をcontinueして分散寄与0。警告付きだがstatus=ok、approximate=false、p=0.512485…を返す。

確定修正：初期リリースのlonelyPSUPolicyはfailのみ。記述表は返し、推測status=unavailable、reason=SURVEY_LONELY_PSU、p/自由度/星null。確実抽出・層併合・adjustを自動仮定しない。[R3]

根拠コード：`backend/app/algorithms/survey/covariance.py::linearized_total_covariance; algorithms/summaries/inference.py`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/03_state_design.json#lonely_psu`。

自動回帰：

- `test_survey_contracts.SurveyDesignTests.test_SD04_lonely_psu_does_not_report_successful_design_inference`：現版FAIL。

---

### SD05 [P1] 未検証のFPCが分散を0へ切り捨てる

確認区分：現版実行＋ソース照合。

再現条件：2PSUを抽出した設計に、現実装が母集団PSU数として読むfpc=1を指定。

現版の結果：(population-count)/populationをmax(0,…)で0へ切り捨て、分散[[0.0]]を返す。FPCの個数/抽出率の区別、層内整合性も未検証。

確定修正：今回の受入範囲ではFPC/複製重みは未対応と確定。非null指定は422 SURVEY_DESIGN_UNSUPPORTED、保存・推測しない。別リリースでpopulationSize/samplingFractionを型分離し、既知oracleとの一致を条件に解禁。[R1]

根拠コード：`backend/app/algorithms/survey/covariance.py::linearized_total_covariance; domain/codebook.py`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/03_state_design.json#invalid_fpc_covariance`。

自動回帰：

- `test_survey_contracts.SurveyDesignTests.test_SD05_invalid_fpc_cannot_turn_variance_to_zero`：現版FAIL。

---

### SD06 [P1] ウェイト変更後も旧ウェイトに結び付いた設計が残る

確認区分：現版実行＋ソース照合。

再現条件：weightConfig=w、surveyDesign.weightColumnId=wから、weightConfigだけw2へ変更。

現版の結果：保存後はweightConfig=w2、surveyDesign.weightColumnId=wで不一致。

確定修正：重み列・意味を変更しsurveyDesignを同一リクエストで再指定しない場合、設計をnullへ解除。レスポンスと画面へ解除理由を返し、同一schemaRevisionの原子的変更にする。

根拠コード：`backend/app/api/datasets.py::update_codebook,_update_codebook`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/03_state_design.json#switch_weight_book`。

自動回帰：

- `test_survey_contracts.SurveyDesignTests.test_SD06_changing_weight_invalidates_stale_design_atomically`：現版FAIL。

---

### SD07 [P1] フィルタ後の設計再作成でドメイン分散の契約が不足する

確認区分：静的確認・数値oracle照合未実施。

再現条件：層化・クラスタ設計で選択群/active群のみをクロス集計するコード経路を確認。

現版の結果：選択群と両設問有効者に絞った行だけで層・PSUを組み直す。母標本の設計情報やゼロ寄与PSUを保持するドメイン契約がない。Rとのp値差の網羅再現は未実施。

確定修正：この修正版でprovided designの部分母集団推測は未対応とし、scopeが全件でない、または設問欠損により設計対象が変わる場合は推測unavailable（記述は可）。将来、元設計を保持するdomain indicator方式を別ADR・R oracle試験で実装して解禁する。weights-only近似は当該対象行の独立性仮定を明示して継続可。

根拠コード：`backend/app/api/summaries.py::crosstab_summary; algorithms/summaries/crosstab.py::compute_crosstab`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/ソース照合：scopeでdfを削ってからdesignを構築`。

自動回帰の直接対応：なし。`FIX_SPEC.md`の手動/参照環境の受入条件で扱う。ソース照合を数値試験の代わりに合格とはしない。

---

### IM01 [P0] 欠損コードをドナーとして使い補完値を汚染する

確認区分：現版実行＋ソース照合。

再現条件：x=[1,3,99,None]、99=普通の欠損、mean補完。

現版の結果：Noneだけ34.3333で埋まり、99は残る。正しいドナー1,3の平均2ではない。補完前の普通集計と補完器の意味が違う。

確定修正：欠損理由分類を計画作成時に適用。missingは対象セル、not_applicableは対象外、invalidは明示修正まで補完しない。ドナーもpredictorも普通欠損コードを有効値に使わない。本例の現在値[1,3,2,2]、rawは[1,3,99,None]を保持。

根拠コード：`backend/app/api/datasets.py::_impute_dataset; algorithms/imputation/plan.py; algorithms/imputation/core.py::impute_dataframe`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/02_workflows.json#impute_values / impute_summary`。

自動回帰：

- `test_survey_contracts.ImputationHistoryPackageTests.test_IM01_missing_code_neither_donor_nor_unfilled_ordinary_missing`：現版FAIL。

---

### IM02 [P1] 補完プレビューのハッシュが設問の意味変更を検出しない

確認区分：現版実行＋ソース照合。

再現条件：プレビュー後、xのmissingCodesを変更して再プレビュー・旧planHashで適用。

現版の結果：planHashが同一で旧計画が受理される。dataset/dataRevisionは含むがschemaRevisionや欠損意味を含まない。

確定修正：planHashにdata/schema/maskRevision、scopeHash、raw/score semantic hash、対象/説明列、method/options/seed、algorithmVersionを入れる。旧計画は409で拒否。previewとapplyは同一計画・同一値ハッシュを照合する。

根拠コード：`backend/app/algorithms/imputation/plan.py::compute_plan_hash; api/datasets.py::preview_dataset_imputation,_impute_dataset`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/03_state_design.json#plan_schema_change`。

自動回帰：

- `test_survey_contracts.ImputationHistoryPackageTests.test_IM02_old_plan_rejected_after_schema_change`：現版FAIL。
- `test_survey_contracts.ImputationHistoryPackageTests.test_IM02_plan_hash_changes_on_missing_semantics_change`：現版FAIL。

---

### PK01 [P0] 予約列名の衝突で取り込んだ原データが失われる

確認区分：現版実行＋ソース照合。

再現条件：CSV __rowId__,q / a,1 / a,2 を通常取込。

現版の結果：HTTP200のままa,aをROW-000001/2で上書きし、原入力列としても残さない。raw作成前の消失。

確定修正：内部予約名の不正な入力（重複/空/不正ID）は通常取込で422 RESERVED_COLUMN_CONFLICT、書込みなし。自動上書きは禁止。正規パッケージ復元だけ、検証済み内部IDを受理する。通常CSVで外部IDを使うときは明示rowIdColumnと元列保存を両立する。

根拠コード：`backend/app/storage/dataset_store.py::assign_row_identity; api/datasets.py::import_dataset`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/03_state_design.json#reserved_http`。

自動回帰：

- `test_survey_contracts.ImputationHistoryPackageTests.test_PK01_reserved_id_input_is_rejected_not_overwritten`：現版FAIL。

---

### PK02 [P0] パッケージ復元が原本を補完後の現在値に取り替える

確認区分：現版実行＋ソース照合。

再現条件：x=[1,3,None]をmean補完してエクスポート→インポート。

現版の結果：元raw=[1,3,None]、current=[1,3,2]。復元先ではrawも[1,3,2]。raw_dfを読むのに保存せず、行数だけで検証している。

確定修正：rawとcurrentを別ストリームとして原子的に復元。新版パッケージは型付きraw.parquetを正本、raw.csvは閲覧用。値・列型・row identity・マスク対応を検証し、原本復元が元の欠損へ戻ることを保証。旧版のCSV型曖昧性は明示警告、勝手にcurrentをrawへ代入しない。

根拠コード：`backend/app/api/datasets.py::export_package,import_package`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/03_state_design.json#package_import`。

自動回帰：

- `test_survey_contracts.ImputationHistoryPackageTests.test_PK02_package_roundtrip_preserves_original_missing_raw`：現版FAIL。

---

### PK03 [P1] パッケージ内のdatasetIdと履歴カーソルが移行されない

確認区分：現版実行＋ソース照合。

再現条件：同じパッケージを別datasetとして復元し、コードブック・sessionState・provenanceを読む。

現版の結果：新datasetIdに対しcodebook.datasetIdとsessionState.datasetIdが旧IDのまま。旧履歴カーソルも残り、現履歴スナップショットのない操作を参照する。

確定修正：新IDをactiveメタ情報全体へ再割当て。sourceDatasetIdは来歴として別保持。持ち込んだ過去履歴はread-only archive、編集履歴はimportを新rootとして開始する。旧snapshotを持たないUndoは表示しない。raw/currentの復元はPK02どおり維持。

根拠コード：`backend/app/api/datasets.py::import_package`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/03_state_design.json#package_import`。

自動回帰：

- `test_survey_contracts.ImputationHistoryPackageTests.test_PK03_package_import_rebinds_codebook_dataset_id`：現版FAIL。
- `test_survey_contracts.ImputationHistoryPackageTests.test_PK03_package_import_rebinds_session_dataset_id`：現版FAIL。

---

### PK04 [P1] manifestの検証対象を空にしても復元成功する

確認区分：現版実行＋ソース照合。

再現条件：パッケージmanifest.filesだけ[]へ変更し復元。

現版の結果：HTTP200。必須ファイルの存在は確認するが、checksum検証は自己申告されたfiles一覧にだけ依存する。

確定修正：必須・許可エントリ集合、重複、パス、非圧縮サイズ、SHA-256、型をサーバで検証。manifest以外の全payloadを一度ずつ記載必須。署名のないSHAは出所認証ではなく整合性検証である点も明記する。

根拠コード：`backend/app/api/datasets.py::import_package`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/03_state_design.json#manifest_missing_entries`。

自動回帰：

- `test_survey_contracts.ImputationHistoryPackageTests.test_PK04_manifest_must_cover_every_payload`：現版FAIL。

---

### PK05 [P1] コードブックJSONの往復で重み・調査設計が復元されない

確認区分：現版実行＋ソース照合。

再現条件：weightConfigとsurveyDesignを持つコードブックをJSON書出し、設定解除後に再読込み。

現版の結果：列設定は読まれるがweightConfig、surveyDesignはNoneのまま。配布設定と再読込後の解析条件が一致しない。

確定修正：JSONはtyped codebook全体を往復させる。列ID/名前対応を先に検証し、weight/designの参照を再マップ。適用前diffを返し、受理対象外フィールドは422または明示警告。JSONの正常roundtripは設定完全一致を受入条件とする。

根拠コード：`backend/app/api/datasets.py::import_codebook,export_codebook`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/02_workflows.json#codebook_roundtrip; unittest/test-results.json#test_PK05_codebook_json_roundtrip_restores_weight_and_design`。

自動回帰：

- `test_edge_contracts.EdgeContractTests.test_PK05_codebook_json_roundtrip_restores_weight_and_design`：現版FAIL。

---

### V01 [P1] 探索後の分割を独立した検証として表示する

確認区分：現版実行＋ソース照合。

再現条件：80人全員を使って候補を選び、その候補をholdoutまたは5-fold検証。

現版の結果：候補選択に関与済みの行を後で分割し、isExploratory=false・有意/再現判定を返す。CV見出しでは全80人を再評価している。候補を固定保存する改善自体は確認。

確定修正：現フローはposthoc_stabilityに固定しisExploratory=true、確認的p/q/significant/replicationをnull。記述効果・fold安定性は提供可。独立検証は探索前に予約したholdoutか、来歴で独立性を確認できる別標本だけ。EDA自体にholdoutを要求しない。[R4]

根拠コード：`backend/app/api/mining.py::_verify_subgroups`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/02_workflows.json#verification_holdout / verification_cross_validation`。

自動回帰：

- `test_survey_contracts.MiningVerificationTests.test_V01_posthoc_cv_not_confirmatory`：現版FAIL。
- `test_survey_contracts.MiningVerificationTests.test_V01_posthoc_holdout_not_confirmatory`：現版FAIL。

---

### V02 [P0] 探索と検証で逆転項目の向きが反対になる

確認区分：現版実行＋ソース照合。

再現条件：A群raw平均1.5、B群4.5、1～5逆転。探索後に固定候補を検証。

現版の結果：探索は得点平均4.5対1.5、差+3。検証はrawへ戻り全件差-3、holdout差-3.0979、replicationStatus=reversed。真の方向変化ではない。

確定修正：固定候補へscoreSpecHash、target/comparator/estimandを保存し、探索・検証とも共通AnalysisFrameを使う。検証で規則の方向や基準群を再選択しない。全件安定性では差+3、directionConsistent=true。

根拠コード：`backend/app/api/mining.py::_prepare_mining,_verify_subgroups; algorithms/mining/verification_test.py::compute_estimand`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/02_workflows.json#exploration_reversed / verification_holdout / verification_cross_validation`。

自動回帰：

- `test_survey_contracts.MiningVerificationTests.test_V02_verification_uses_reversed_analysis_scores`：現版FAIL。

---

### V03 [P2] 5-foldの各効果量がnullになる

確認区分：現版実行＋ソース照合。

再現条件：検証可能な群差を持つ80人でk=5。

現版の結果：5foldは作られているが全foldのeffects.effectがnull。compute_estimandのeffect.estimateではなくeffect.effectを読んでいる。旧「最初のfoldしかない」とは別の現版不具合。

確定修正：型付きEffectResultを利用しestimateを参照。foldごとのn/used/exclusions/estimateを出力。nullは評価不能時だけ、reason必須。安定性の各fold値を全体pの根拠にしない。

根拠コード：`backend/app/api/mining.py::_verify_subgroups`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/02_workflows.json#verification_cross_validation`。

自動回帰：

- `test_survey_contracts.MiningVerificationTests.test_V03_all_five_cv_folds_have_effect_values`：現版FAIL。

---

### V04 [P1] 候補固定後のコードブック変更を失効させない

確認区分：現版実行＋ソース照合。

再現条件：候補を固定後、q.isReversedを変更して古いcandidateSetHashで検証。

現版の結果：変更後schemaRevisionでも受理。候補セットにschemaRevisionは保存するがロード時に比較しない。

確定修正：同一datasetではdata/schema/maskRevision、scopeHash、scoreSpecHashの不一致を409。別データではrevision番号同値を要求せず、変数意味・尺度・カテゴリ・得点規則の互換性を照合する。

根拠コード：`backend/app/api/mining.py::_load_candidate_set`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/02_workflows.json#stale_candidate_schema`。

自動回帰：

- `test_survey_contracts.MiningVerificationTests.test_V04_candidate_stale_schema_is_rejected`：現版FAIL。

---

### V05 [P1] 多重比較補正の指定名と計算が一致しない

確認区分：現版実行＋ソース照合。

再現条件：correction="not-a-method"を送る。

現版の結果：受理して同名をメタデータへ返すが、実処理はBHに固定。

確定修正：今回受入はBHだけに限定し、correction="bh"以外は422。alphaは0<alpha<1、kは2以上かつ対象件数以下。表示名を入力の単純エコーにせず実施methodから生成。将来他手法を実装するまで選択肢へ出さない。

根拠コード：`backend/app/api/mining.py::VerificationConfig,_verify_subgroups`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/02_workflows.json#unsupported_correction`。

自動回帰：

- `test_survey_contracts.MiningVerificationTests.test_V05_unknown_correction_is_rejected`：現版FAIL。

---

### V06 [P1] modern候補の独立データ検証から条件列が落ちる

確認区分：現版実行＋ソース照合。

再現条件：規則g=A、target=qのmodern候補を別データで評価。

現版の結果：_needed_columnsは[q]しか返さず、存在するgを検証用frameから落とす。結果COLUMN_NOT_FOUNDで評価不能。

確定修正：規則ASTを再帰走査し条件列、target列、targetPair、weight/design列を依存関係として収集。canonical columnIdを別datasetの明示対応表で解決する。

根拠コード：`backend/app/api/mining.py::_needed_columns,_independent_frame`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/02_workflows.json#modern_needed_columns / modern_independent`。

自動回帰：

- `test_survey_contracts.MiningVerificationTests.test_V06_modern_rule_columns_in_independent_frame`：現版FAIL。

---

### V07 [P1] カテゴリ目的のmodern候補を平均差として固定する

確認区分：候補変換・評価関数の契約試験（modern探索→UIの全経路は未実施）。

再現条件：yes/noターゲット、選択カテゴリyes、g=Aの候補入力をmodern_candidateへ渡して評価。

現版の結果：カテゴリメタデータを無視してmean_differenceへ固定。yes/noを有限数にできずINSUFFICIENT_GROUP_SIZE。入力例のyes比率差は0.5。

確定修正：Engine結果へtargetKindとtargetCategoryを必須化。カテゴリ目的は固定カテゴリのproportion_difference、数値目的はmean_difference、EMMはtau_difference。未知種類を平均へフォールバックしない。

根拠コード：`backend/app/domain/mining_candidate.py::modern_candidate; algorithms/mining/verification_test.py::compute_estimand`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/02_workflows.json#modern_categorical`。

自動回帰：

- `test_survey_contracts.MiningVerificationTests.test_V07_nominal_modern_target_pins_proportion_not_mean`：現版FAIL。

---

### SN01 [P0] 感度分析が欠損・逆転前の値で正反対の効果を返す

確認区分：現版実行＋ソース照合。

再現条件：A=[1,1,2,2]、B=[4,4,5,99]、99欠損、1～5逆転、外れ値除外なし。

現版の結果：baseline差-26.5、有効8、isRobust=true。解析得点での正しい差は17/6=2.8333、有効7。

確定修正：探索・検証と同じ固定estimandとAnalysisFrameを使い、baseline/sensitivity間で変えるのは除外方針だけ。99を外れ値候補や比較のドナーにしない。

根拠コード：`backend/app/api/robustness.py::run_sensitivity; algorithms/robustness/sensitivity.py`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/02_workflows.json#sensitivity_raw`。

自動回帰：

- `test_survey_contracts.SensitivityTests.test_SN01_sensitivity_matches_missing_and_reverse_contract`：現版FAIL。

---

### SN02 [P1] 群差の条件欠落が全体平均へ黙って置き換わる

確認区分：現版実行＋ソース照合。

再現条件：candidate.type=subgroup_diffだがgroupColumn/compareGroupsなしで実行。

現版の結果：群比較を拒否せず、全体KPI平均14.75を返す。

確定修正：candidateは判別共用体として型検証。subgroup_diffには群定義・比較群必須、欠落422。kpiへの自動変更禁止。

根拠コード：`backend/app/algorithms/robustness/sensitivity.py; api/robustness.py::SensitivityRequest`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/02_workflows.json#sensitivity_missing_group`。

自動回帰：

- `test_survey_contracts.SensitivityTests.test_SN02_group_diff_without_groups_is_not_overall_mean`：現版FAIL。

---

### SN03 [P1] KPIの区間がWelchと名乗りながら固定1.96で計算される

確認区分：現版実行＋ソース照合。

再現条件：KPI q=[1,2,3,4]で区間を検査。

現版の結果：confidenceMethod=welch_t_intervalだが1.96*SEを使う。群差のWelchと単一平均の区間を同じ名称にする。

確定修正：単一平均はstudent_t_mean、t(n-1)を使用。群差はwelch_t_differenceとする。N<2/非有限分散は区間null・reason必須。bootstrapは現処理では実行していないため、その回数を実行済みとして表示しない。

根拠コード：`backend/app/algorithms/robustness/sensitivity.py::_mean_ci`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/02_workflows.json#sensitivity_kpi; unittest/test-results.json#test_SN03_kpi_small_sample_uses_student_t_interval`。

自動回帰：

- `test_survey_contracts.SensitivityTests.test_SN03_kpi_small_sample_uses_student_t_interval`：現版FAIL。

---

### CTX01 [P2] 空のexplicit scopeだけ不正入力になる

確認区分：現版実行＋ソース照合。

再現条件：scope=explicit,rowIds=[]。active/sample空も比較。

現版の結果：active/sampleの[]は正しく0件になったが、explicitはrequires rowIdsで拒否。全件へ拡大する旧バグは修正済み。

確定修正：None=未指定、[]=明示0件を全scopeで統一。explicit/selected/sampleに必須配列がNoneなら422、[]なら0件。0件結果はnull統計と母数0を返す。

根拠コード：`backend/app/domain/context.py::AnalysisContext; api/summaries.py::crosstab_summary`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/01_core.json#scope_empty_explicit / scope_empty_active`。

自動回帰：

- `test_survey_contracts.ScopeModelTests.test_CTX01_empty_active_stays_empty`：現版PASS。
- `test_survey_contracts.ScopeModelTests.test_CTX01_empty_explicit_is_valid_empty_scope`：現版FAIL。
- `test_survey_contracts.ScopeModelTests.test_CTX01_empty_sampled_stays_empty`：現版PASS。

---

### CTX02 [P1] 範囲選択が実在しないrowIdを返す

確認区分：現版実行＋ソース照合。

再現条件：activeRowIds=[not-real]、from=0,to=1。

現版の結果：存在検証をせずnot-realを選択結果へ返す。sample側のunknown IDは今回422に修正済み。

確定修正：全選択APIで共通scope resolverを使用し、unknown IDは422、古いrevisionは409。リストの順序を使う範囲選択と集合選択の意味を区別して保持。

根拠コード：`backend/app/api/observations.py::select_range_observations`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/01_core.json#range_unknown`。

自動回帰：

- `test_survey_contracts.ScopeModelTests.test_CTX02_range_rejects_nonexistent_active_id`：現版FAIL。

---

### CTX04 [P1] 復元抽出の重複回数が後続集計で消える

確認区分：現版実行＋ソース照合。

再現条件：x=[0,10,100]から復元5件seed42を抽出し、返却sampledRowIdsをsummaryへ渡す。

現版の結果：抽出は[0,100,10,10,10]で平均26だが、summaryはis_inで集合化し3人の平均36.6667になる。返却multiplicityが後続契約に渡らない。

確定修正：今回の全体選択サンプリングは非復元抽出のみに確定。with_replacementは422 SAMPLING_REPLACEMENT_UNSUPPORTED。bootstrap内部の再標本化は別機能。重複IDをsurvey weightへ混ぜて対症療法にしない。

根拠コード：`backend/app/api/observations.py::sample_observations; api/summaries.py::_summaries`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/01_core.json#sample_multiplicity`。

自動回帰：

- `test_survey_contracts.ScopeModelTests.test_CTX04_shared_scope_replacement_sampling_disabled_until_multiplicity_supported`：現版FAIL。

---

### CTX05 [P1] KDAが対象行と世代指定を無視する

確認区分：現版実行＋ソース照合。

再現条件：8行から先頭4行rowIdsを指定、別試験でexpectedDataRevision=999。

現版の結果：モデルがフィールドを持たず捨てるため全8行を解析し、古いrevisionも成功。

確定修正：KDAを共通AnalysisContextへ移行し、rowIds・data/schema/maskRevisionを適用。対象4ならmodel.n_valid=4。未対応weightはscope単位の明示unsupportedとして分離。未知フィールドは422。

根拠コード：`backend/app/api/models.py::KdaRequest,calculate_kda`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/03_state_design.json#kda_scope`。

自動回帰：

- `test_survey_contracts.ScopeModelTests.test_CTX05_kda_row_scope_is_applied`：現版FAIL。
- `test_survey_contracts.ScopeModelTests.test_CTX05_kda_stale_data_revision_is_rejected`：現版FAIL。

---

### CTX06 [P2] 大きなデータを減らすsampling API自身が入口で拒否する

確認区分：現版実行＋ソース照合。

再現条件：100001個の合成rowIdをstore戻り値として与え、非復元10件を指定。

現版の結果：413となり「サンプリング機能を利用してください」と案内する。全データ取込の性能測定ではなく実関数の件数分岐を検査。

確定修正：入力母数に100000のUI転送上限を適用しない。samplingはサーバ内で行い、上限は出力件数へ適用。データセット自体の正規max_rows制約は残す。

根拠コード：`backend/app/api/observations.py::sample_observations`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/unittest/test-results.json#test_CTX06_sampling_can_reduce_more_than_100000_rows`。

自動回帰：

- `test_edge_contracts.EdgeContractTests.test_CTX06_sampling_can_reduce_more_than_100000_rows`：現版FAIL。

---

### UI01 [P1] 大きなクロス表セルの再取得で表示時のscopeが落ちる

確認区分：現配布JSの静的確認＋共通scopeコード照合（ブラウザ未実施）。

再現条件：セルrowIds切捨て後の/summaries/crosstab/cell-row-idsリクエスト構築を確認。

現版の結果：contextへscope文字列だけを入れ、activeRowIds/selectedRowIds/sampledRowIds/rowIdsを渡さない。active/sampleは元より広い集合、selected等はエラーになり得る。ブラウザ操作での再現は未実施。

確定修正：表を生成したcontextを不変オブジェクトとして保持し、再取得へそのまま渡す。UIの現在選択を再読込して再構成しない。scopeHashとrevisionを応答でも照合する。手動受入E2E-U01を必須化。

根拠コード：`backend/app/frontend/dist/assets/index-5mARUBaL.js（整形版14011行付近）; api/summaries.py::crosstab_cell_row_ids`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/frontend.pretty.js の rowIdsTruncated 分岐`。

自動回帰の直接対応：なし。`FIX_SPEC.md`の手動/参照環境の受入条件で扱う。ソース照合を数値試験の代わりに合格とはしない。

---

### SE01 [P1] 静的配信が公開フォルダの外へ到達する

確認区分：現版実行＋ソース照合。

再現条件：監査用frontend/distと、その2階層上に監査用sentinelだけを作り、ASGI経由で公開範囲の境界を検査。

現版の結果：公開フォルダ外の監査用文字列AUDIT-ONLY-NOT-A-USER-FILEをHTTP200で返した。ユーザー原票・秘密ファイルは読んでいない。Windowsの実ネットワークでの到達性や攻撃成立条件まで測定したものではない。

確定修正：候補パスをresolveし公開root配下のみ許可。絶対パス、..、デコード後の区切り、外向きsymlinkは404。既知のassetsとindex以外を無制限に返さない。可能なら通常static handlerへ限定。

根拠コード：`backend/app/main.py::spa_fallback`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/04_delivery_edges.json#path_boundary`。

自動回帰：

- `test_edge_contracts.EdgeContractTests.test_SE01_static_fallback_rejects_outside_directory`：現版FAIL。

---

### DEP01 [P2] ランチャーが更新後の依存変更と空白パスに弱い

確認区分：静的確認（Windows未実施）。

再現条件：依存導入条件とPython実行パスの組立てを静的確認。

現版の結果：.installedとimport可否だけで導入済みを判定し、requirements変更を検知しない。実行パスを無引用で呼ぶ分岐もある。Windows実行は未実施なので確定再現値はない。

確定修正：requirements hashとPython実体/versionを導入stampへ保存。差分時は再検証して失敗なら起動停止。実行ファイルと引数を分離し全パスを引用。空白を含む標準ユーザーパスでWindows受入E2E-P01を実施。

根拠コード：`backend/app/run-local.bat`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/現配布batの .installed / PY_CMD 呼出し`。

自動回帰の直接対応：なし。`FIX_SPEC.md`の手動/参照環境の受入条件で扱う。ソース照合を数値試験の代わりに合格とはしない。

---

### AV10 [P1] LOESSの「95%区間」に対応する分散計算が保証されない

確認区分：数式・名称の静的照合（区間被覆率のシミュレーションは未実施）。

再現条件：fit_localとcurveのciLower/ciUpper算出式を確認。

現版の結果：局所訓練点Hの対角平均をgrid点の予測分散の代わりにし、1.96*残差SD*sqrt(平均leverage)を95%区間として返す。検証された点別分散/自由度の実装ではない。微小残差で外れ値が生じる境界も04の完全直線例で観測した。

確定修正：今回の修正版ではLOESSの確率付き区間を非表示、ciLower/ciUpper=null、intervalStatus=unsupportedとする。曲線・記述残差は維持。点別平滑化重みと残差自由度を用いた検証済み区間を別リリースで追加するまで「95%」を使わない。

根拠コード：`backend/app/algorithms/regression/loess.py::compute_loess`。フロント・batはプロジェクトルート相対。正確なPythonシンボル行範囲は`source_index.json`を参照。

実行証拠：`evidence/ソース：局所Hの対角平均をgrid予測のleverageに流用`。

自動回帰の直接対応：なし。`FIX_SPEC.md`の手動/参照環境の受入条件で扱う。ソース照合を数値試験の代わりに合格とはしない。

---

## 6. 証拠の読み方

`evidence/01_core.json`は尺度・重み・設計・分布・sampling、`02_workflows.json`は探索/検証・感度・補完・Undo/Redo・MA、`03_state_design.json`は設計分散・schema・計画ハッシュ・モデル・パッケージ、`04_delivery_edges.json`はLOESSと公開範囲の実行値を収録する。乱数seedは各fixtureに固定し、datasetId/操作IDは衝突回避のため毎回生成する。

JSONには検証中に否定された仮説もある。例：`01_core.fisher_separation`は誤ったmethod名`fisher`に対する拒否、`02_workflows.fisher_exact`は正しい名前でHTTP200である。Fisherの完全分離が500になるとは報告していない。実行出力は証拠原票であって、すべてのキーが不具合を意味するわけではない。

テストログのPASS/FAILが実行事実、`FIX_SPEC.md`の規則は今回固定した設計判断である。過去の監査IDとは別体系を使い、現在存在しない古い不具合を番号だけで復活させない。

## 7. 統計的な根拠

[R1] R survey `svydesign`（作者の一次資料）。最小引用：`nest=TRUE`、`must not have any missing values`。層内PSU識別と設計変数の欠損検査を裏付ける。PSUを省略した層化標本の例も掲載されている。参照ページの版は3.19であり、今回のアプリと最新Rパッケージとの数値同値を保証する資料としては使っていない。

[R2] R survey `svychisq`。最小引用：`Rao-Scott second-order correction`。F方式の第2次補正とSatterthwaite近似を説明する。Kish ESSによる単一スカラー補正とは別物として実装・表示する。

[R3] R survey, Lonely PSUs。最小引用：`survey.lonely.psu="fail"`。非確実抽出の単独PSU層を、黙って分散0としない根拠。資料に複数の調整方法があることは認めたうえで、今回の製品仕様はfailに限定する。

[R4] scikit-learn, Common pitfalls。最小引用：`Data leakage`。同資料の学習/評価分離と前処理一致の原則を、ここでは候補選択と候補評価の分離へ適用している。アンケートEDAに学習用/テスト用分割を常時義務付ける主張ではない。

参照先は`SOURCES.md`。いずれも原著者・公式文書を使用した。数値のバグ判定自体はこれらの一般説明だけでなく、現ソースと合成fixtureで確認した。

## 8. リリース判定

まずP0と基礎統計/weight/contextのP1を修正する。誤った検証済み表示、未対応設計の推測、未検証LOESS区間は明示的に停止できる。テストを緩める、expectedFailureにする、警告だけ追加して誤った数値を残すことは完了ではない。

70件のPython試験が指定ネイティブ環境で全通過し、ブラウザ選択連動とWindows起動の必須受入を通過するまで正式な分析結果確定用の版としない。Rao–Scottの設計対応を提供する部分は、独立したR oracle照合を別に必須とする。WASMでの今回の結果だけをそのリリース承認へ代用しない。
