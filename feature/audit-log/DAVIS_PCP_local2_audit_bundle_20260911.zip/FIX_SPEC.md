# DAVIS-PCP アンケートEDA：確定修正仕様

版：1.0 / 2026-09-11  
基準ZIP：`davis-pcp-local(2).zip`  
SHA-256：`4965801943604c16e0eeb51017f00aec9f5dafe18ee3ce1a7c7caa74dfe37673`

この文書は実装者向けの決定事項である。「推奨案A/B」を残さず、今回の修正版の受入境界まで定める。現版の不具合と再現値は`AUDIT_REPORT.md`、自動受入は`backend/tests/survey_audit/`、実行結果は`evidence/unittest/`を参照する。

## 0. 決定の優先順位と変更管理

数値の正しさ、原本の保存、分析対象者の同一性、表示の正直さを、新機能や過去レスポンスとの完全互換より優先する。従来の欄名は互換表示に残せるが、誤った数値を返して互換を保たない。

判断順は「この文書の規範→修正済み回帰テスト→現UI/既存コード」である。API変更でテストの呼出し形を変えることは許すが、期待する値・母数・拒否条件を緩めることは許さない。文書とテストの不整合が見つかった場合は、勝手に現実装に合わせず、差異・理由・変更後の受入値をADRへ記録する。

仕様変更には、対象ID、変更理由、旧契約との差、統計的根拠、移行方法、対応する独立期待値とテスト更新を必須にする。実装者の都合だけで「近似」「警告付き」「非加重へ代替」に戻さない。

## 1. 今回の修正版の範囲

|機能|今回の確定動作|
|---|---|
|通常集計・MA・相関|共通の対象行、欠損分類、得点変換、weight解決を使用する。対応する記述統計を正しく返す。|
|調査ウェイト|`survey`と`frequency`を区別。surveyは既定でp/星を出さない。|
|Rao–Scott|明示要求時のみ第2次補正。対応設計だけ実施し、未対応は記述表を維持して推測unavailable。|
|層/PSU|層化、層内に入れ子化した単段PSUを対応範囲とする。PSU省略は独立行近似、既知の層は保持。|
|単独PSU層|初期方針はfail。推測unavailable。自動でcertainty/remove/adjustを選ばない。|
|FPC・複製重み・多段設計|今回は未対応。非null指定は422。将来拡張の設定だけを先に受理しない。|
|provided designの部分母集団推測|今回は未対応。記述は提供、推測unavailable。元設計を保持するdomain実装は別ADRで解禁。|
|探索後のholdout/CV|独立検証ではなくposthoc stability。記述効果とfold安定性を返す。|
|独立検証|探索前に予約したholdout、または独立性を確認できる別標本のみ。|
|感度分析|固定estimandの除外前後比較。全体平均へ自動変更しない。|
|LOESS|解析得点による曲線・記述残差を提供。未検証の「95%区間」は停止する。|
|共有scopeのsampling|非復元抽出だけ。復元抽出は422。bootstrap内部とは別契約。|
|パッケージ|raw/currentを別保存し、コードブック・マスク・来歴・ID対応を原子的に移送。|

時系列機能、画像、予測サービス、原典DAVISの完全復刻、高度な複雑標本設計を今回の必須実装へ追加しない。

## 2. 共通AnalysisContext

### 2.1 入力契約

共通内部構造を全解析APIで使う。旧フラットAPIは入口でこの構造へ正規化する。

```json
{
  "datasetId": "ds-...",
  "expectedDataRevision": 12,
  "expectedSchemaRevision": 5,
  "expectedMaskRevision": 3,
  "scope": "selected",
  "selectedRowIds": ["ROW-000001", "ROW-000006"],
  "weightMode": "dataset",
  "missingPolicy": "exclude"
}
```

`scope`はall/active/selected/sampled/explicit。`None`と空配列を区別する。all以外で必要なID集合が未指定なら422。必要な配列が`[]`なら有効な0件scopeであり、全件へ戻さず0件を返す。旧APIの省略をallへ正規化する互換処理は入口でのみ行い、確定済みcontextでは曖昧さを残さない。

unknown IDは422、旧revisionは409。エラー時は解析・書込み・キャッシュ更新をしない。対象行を黙って除去して母数を変えない。範囲選択は入力順に意味があるため順序付き、通常scopeは元データの固定行順を保持した集合として扱う。

request modelは`extra="forbid"`を原則とする。旧名dataset_id/row_idsなど既知の別名は明示aliasとして処理し、未知フィールドを黙って破棄しない。旧名と新名が矛盾したら422。

### 2.2 ScopeSnapshotとドリルダウン

表生成時に、解決済みrowIds、各revision、scopeHash、weightMode、weight/scoreの意味、missingPolicyをScopeSnapshotとして保存する。クロス表のセル所属取得、PCP選択、説明文、出力に同一snapshotを渡す。UIの現在の選択状態を読み直してcontextを組み立てない。

セルrowIdsを切り捨てる場合でもcontextを省略しない。スコープトークン方式を採る場合はdataset/revisionsとの結び付きをサーバで検証し、期限切れを409にする。今回はクライアントで不変contextを保持する方式を標準とする。

### 2.3 応答とキャッシュ

応答metaにはdata/schema/maskRevision、scopeHash、scopeCount、algorithmVersion、weightMode、scoreSpecHashを返す。各統計の有効母数はmeta.scopeCountとは分ける。

cache keyは少なくともdatasetId、全revision、scopeHash、解析列ID順、scoreSpecHash、weightMode/列/種類、設計hash、missingPolicy、method/options、algorithmVersionを含める。列順に表示意味がある出力を、列IDをソートしたcache keyだけで使い回さない。Undo/Redo、コードブック変更、weight変更、mask変更は別世代として検証する。

## 3. AnalysisFrame：欠損と得点を一箇所で定義する

### 3.1 値空間の分離

各変数に対して以下を保持する。すべてをDataFrameの同じ列に上書きして意味を失わせない。

```text
rawValue         取り込んだ原本の値
currentValue     編集・補完後の現在値
normalizedCode   カテゴリ同定用の正規化コード
analysisValue    順序得点・逆転処理後の解析値
validity         valid / missing / not_applicable / invalid
imputed          現在セルが補完値かどうか
scoreSpecHash    同じコードから同じ解析値へ写像する規則の識別子
```

missingCodes/reasonsを適用した後、尺度に応じたparse・領域検証をする。数値parse失敗をカテゴリ順位に変換しない。None/NaNとコードブック上の普通欠損はmissing、非該当はnot_applicable、領域外や型違反はinvalidとする。非有限数値は解析に入れない。

今回のinvalidの集計方針は「当該変数の解析から除外し、invalidCountと該当コードを表示」で固定する。ただしコードブック自体が不正な場合は解析を422で停止する。invalidを普通欠損へ黙って変換して補完してはならない。

### 3.2 順序と逆転

数値コードのordinalで順序が未指定の場合は、全データを参照して数値昇順を一度だけ確定しコードブックへ保存する。subsetごとの推定は禁止。文字列ordinalで順序未指定は422。

既定得点は保存済みcategoryOrderの1始まり順位。実数得点を使う場合は明示scoreMapに保存する。コード番号の差を無条件に距離として採用しない。

逆転の上下限は保存済み尺度領域からのみ決める。理論境界が不明のnumericをisReversedにする更新は422。1～5を宣言した離散尺度では常に`6-x`とする。今回の移行では、現コードが逆転境界として利用している数値categoryOrderを離散得点領域として固定する。連続範囲は別のvalidRange/reverseBoundsへ明示移行する。

宣言1～5に対する9はinvalid。部分集団のmin/max、未定義カテゴリの追加、観測外れ値によって逆転範囲を拡大しない。

### 3.3 統計と表示の統一

主平均、auxiliaryStats、weightedMean、相関、FEDF、QQ、LOESS、探索、検証、感度分析、KDAは、必要な変数ごとに同一AnalysisFrameを使用する。主平均と補助平均は出力精度差以外で一致する。全正重みが1なら同じ有効者集合上の加重平均と非加重平均が一致する。

カテゴリ度数はnormalizedCode、得点統計はanalysisValueで計算する。この違いを説明し、元コード・ラベルを逆転得点へ上書きしない。図がraw空間を要求する場合は`valueSpace="raw"`を明示し、analysis空間の結果と同じ凡例で混在させない。

### 3.4 分母

変数ごとの非加重母数は次に固定する。

```text
scopeN = validN + missingN + notApplicableN + invalidN
eligibleN = scopeN - notApplicableN
validN = 実際にその統計に入る有効回答数
```

クロス表・相関では両変数有効のpairwiseValidNを別に計算する。割合の各フィールドに対応する分母名をスキーマで明記する。NAを通常の欠損として補完したり、未選択を欠損に置き換えたりしない。

### 3.5 分布・平滑化

FEDF同値は平均順位に統一し、p=(averageRank-0.5)/nとする。jitterは表示だけに限定する。QQの定数列・N不足は検定不能でpと判定をnullにする。通常の非棄却は「正規性を棄却しない」と表示する。

LOESSのcurve/points/residualは同じanalysisValueを使う。今回の95%帯は停止し、ciLower/ciUpper=null、intervalStatus=unsupportedとする。数値誤差程度の残差を外れ値にすることを避けるため、残差SDに尺度依存の数値許容差を設け、最大残差が許容差以下なら外れ値0とする。統計的外れ値と数値丸め誤差を区別する。

## 4. ウェイト契約

### 4.1 適用の選択と意味

全APIで以下の解決規則を使う。

|weightMode|動作|
|---|---|
|dataset（既定）|保存済みweightConfigを使う。設定なしなら非加重。|
|none|保存済み設定があっても今回の解析は非加重。|
|column|リクエストで列と種類を明示。保存済み設定は変更しない。|

旧weightColumnが非nullのリクエストはcolumn相当に正規化する。種類は同じ列の保存済みweightConfigから解決できる場合だけ補完し、それ以外はweightType必須として422。旧省略/nullはdatasetに移行する。したがってフロントの「ウェイトなし」は必ずweightMode=noneを送信する。

weightType=surveyは代表性の調整係数、frequencyは実観測の件数。値の整数性を見て種類を自動推定しない。全員1であってもsurveyの設定をfrequencyへ変更しない。

### 4.2 検証順

scope確定→重み列のコードブック欠損分類→有限性/符号/整数性→解析変数との有効集合の共通部分、の順序とする。scope外の不正重みを理由にscope内の解析を非加重へ変えない。

普通欠損の重みは加重統計から除外しweightMissingCountに計上。0は有効な重み値だが正重みの統計には寄与しない。負・Inf・意味不明文字は422。frequencyの非整数は422。surveyの小さい正実数を表示丸めで0にしない。weightSum=0なら結果をno_positive_weightとして扱い、非加重の代替結果を成功扱いで返さない。

### 4.3 記述量

加重平均は`sum(w*x)/sum(w)`。加重相関はペア有効・正重みの集合で、加重中心化後の共分散を使う。相関行列の各ペアにvalidN/weightSumを保持する。ウェイトなしの結果を残す場合は別フィールドにし、どちらが主表示かをweightModeに従って固定する。

内部計算に表示用roundを入れない。重み倍率cに対し、割合・平均・相関・survey推測は不変、weightSum/加重度数はc倍。frequencyは件数の意味が変わるのでp値の倍率不変を要求しない。

weightDiagnosticsは当該統計の有効・正重み集合に統一する。scope全体の診断はscopeWeightDiagnosticsへ分離する。Kish ESSは`(sum w)^2/sum(w^2)`の診断値であり、表の実回答者数や調査設計を反映した推測標本数と同一視しない。

### 4.4 MA

現版の「完全な回答パターンを持つ回答者をvalidとする」基本方針を維持する。partial/invalid/not_applicableは別集計し、通常の分母へ混ぜない。すべて0の回答は「何も選ばなかった有効回答」として分母に含める。

```text
weightedValidN = sum(valid respondent weight)
selectedWeighted_j = sum(weight of valid respondents selecting option j)
weightedResponses = sum_j selectedWeighted_j
pctRespondent_j = 100 * selectedWeighted_j / weightedValidN
pctResponse_j = 100 * selectedWeighted_j / weightedResponses
```

pctRespondentは複数回答なので合計100%を要求しない。pctResponseは正の回答総数があるとき合計100%。分母0なら割合null。非加重selectedN/validN/回答数も併記する。MAの加重は検定の設計効果対応を意味しない。

## 5. 調査推測

### 5.1 既定と非表示

過去に確定したWEIGHT-04/B04方針を維持する。surveyは既定で推測OFF。明示inference=rao_scott時だけRao–Scott第2次F補正を実施する。生の加重度数にPearsonをかける、Kish ESSだけでPearsonを縮める、警告だけ追加する修正は採用しない。[R2]

surveyでは通常のセルASRから有意マーカーを作らない。inference=noneはsurvey/frequency/非加重のすべてで全体pとセル星を停止する。descriptive残差を表示するなら名称と用途を明示する。

### 5.2 設計構築

stratumIdとpsuIdは文字列化の前に欠損・invalidを検査する。PSUの内部IDは層とPSUの組にする。層内番号の再利用によってPSU数/自由度/pが変わらないことを不変条件にする。[R1]

PSU省略は1行1PSUとするが、指定された層は残す。設計仮定は`independent_rows_with_known_strata`または`independent_rows`とし、推測は近似と明示する。weightのみでクラスタ構造が分かったとは表示しない。

現対応は単段、FPCなし。指定していない抽出設計を推定・創作しない。weight列や種類の変更時は旧surveyDesignを解除し、利用者が再指定した設計だけを使う。

### 5.3 不成立時の決定

記述表が成立するが推測が不成立の場合、HTTP200で記述表を残し、inference.status=unavailable、pValue/statistic/自由度=null、reasonを返す。

- 単独PSU層：SURVEY_LONELY_PSU。自動certaintyは不可。[R3]
- 正の自由度なし：SURVEY_DF_INSUFFICIENT。
- 提供設計でall以外のscope、または設問欠損によって設計対象が変わる：SURVEY_DOMAIN_UNSUPPORTED。
- 不正な設計値：解析以前の入力エラーとして422。
- FPC/複製重み等の未対応指定：422 SURVEY_DESIGN_UNSUPPORTED。

未対応を近似へ自動変更しない。利用者が設計指定を解除してweights-only近似を明示的に選ぶことは別操作として可能だが、同じ結果バッジを流用しない。

### 5.4 第2次補正の受入

PSU集約、層別共分散、ゼロ周辺の除去、独立性コントラスト、固有値、F統計量、分子/分母自由度、p値を中間値として比較できるようにする。

R surveyの`svychisq(..., statistic="F")`を独立oracleとする。Rのバージョン、surveyバージョン、設定、乱数seed、入力データを固定して記録する。2×2/2×3/3×2、均一/不均一重み、層化独立行、層内PSU再利用、ラベル置換、weight倍率1e-7/1/100、未出現カテゴリ、設計不成立を含める。片方がunavailableなのに小さい数値差として許容しない。

今回の実行ではR oracle照合は未実施である。70件のテストのうちRao–Scott関連は不変条件・設計部品の試験であり、正式なR一致試験の代替ではない。

## 6. 補完

### 6.1 対象・ドナー・値空間

targetColumnsとpredictorColumnsを別指定とする。現在の値の普通欠損だけを対象にする。not_applicable、weight/ID、invalidは自動補完の対象外。カテゴリは宣言領域からのみ補完し、モデル出力の任意実数をカテゴリへ黙って丸めない。

補完はcurrentValueの単位で行い、逆転得点をrawのセルへ書き戻して二重逆転しない。必要な欠損分類・合法値領域はAnalysisFrameから借りるが、書込み値空間を明確に分ける。

整数列に非整数の定数を指定した場合は拒否する。任意の切り捨てをしない。連続値として補完したい場合は列型/尺度の明示変更を先に行う。平均補完が小数を生む場合の型昇格は診断に記録し、カテゴリ/ordinalへ勝手に適用しない。

### 6.2 計画とプレビュー

planHashはdataset/data/schema/maskRevision、scopeHash、scoreSpecHash、targets/predictors、strategy/options/seed、algorithmVersionを含む。previewは実apply計画の部分表示とし、列ごとに別モデルを作らない。

applyはplanHashと現在のrevisionを再検証し、不一致なら409。古い計画を再計算して同じ操作として受理しない。全観測値を変更しないこと、対象セルだけが変更されたこと、適用値hashがpreviewと一致することを検証する。

### 6.3 原本・履歴

rawはimmutable。各操作の現在値、schema/codebook、mask、fingerprint、revisionを原子的にcommitする。Undo/Redoは状態カーソルを移動する操作であり、監査ログの追加と区別する。

すでに通過しているH01〜H04、IM03を後退させない。派生datasetを作るときも親の原本への対応、対象セル、補完手法/設定、元revisionを保持する。新規importと偽装しない。

## 7. 探索、安定性、独立検証

### 7.1 状態を3つに分ける

|状態|利用可能な表示|禁止|
|---|---|---|
|exploration|記述差、効果量、候補ランキング|確証済み・独立再現済み|
|posthoc_stability|固定候補のfold別効果、符号の安定性、対象件数|確認的p/q、再現有意、独立holdoutという表示|
|independent_validation|固定estimandの独立標本評価。仮定と補正方式を明記|候補再探索、評価結果を見た群方向の変更|

現在の全件探索→holdout/CVはposthoc_stabilityへ移行する。互換のanalysisMode=verificationを受けても、methodと候補来歴から実際の状態をサーバが決定する。`isExploratory=true`、確認的pAdjusted/significant/replicationStatus=nullとする。記述effectとdirectionConsistentは返してよい。

独立検証を可能にする分割は候補探索前に確定する。評価側の結果を見て候補、scoreMap、欠損モデル、カテゴリ併合を選ばない。[R4]

### 7.2 固定候補の必須内容

```text
candidateId, canonicalRuleAST, allDependencyColumnIds
sourceDatasetId, sourceDataRevision, schemaRevision, maskRevision
scopeHash, scoreSpecHash, algorithmVersion, parameters
targetKind, targetColumnId / targetPair, targetCategory
estimandType, numeratorRule, comparatorRule, unit
selectionProtocol, selectionRowProvenance, explorationEffect
```

modern条件列を含め、規則ASTを再帰的に走査する。連番candidateIdだけでは固定にならない。集約カテゴリ「その他」を使うなら構成コードを規則に保存する。

数値目的はmean_difference、カテゴリ目的は指定したカテゴリのproportion_difference、対象ペアのEMMはtau_difference。未知のtargetKindをmean_differenceへ落とさない。探索と検証の意味・単位を合わせ、標準化効果と元単位差を同じeffectとして比較しない。

### 7.3 失効と独立標本

同一datasetのdata/schema/maskRevisionやscoreSpecHashが変わったら候補は409で失効。subsetが変わっても同じ候補セットとして再利用しない。

独立datasetではrevision番号の一致を要求せず、変数対応表と意味の互換性を確認する。新datasetで同じROW-000001が生成されたことだけで同一回答者と決めない。一方、元datasetをコピー・補完・パッケージ復元したものは別IDでも独立標本にしない。sourceDatasetId/lineageと、利用可能なら調査固有の回答者IDで確認する。独立性を確認できない場合はdeclared/unknownとして明示し、自動的にverifiedにしない。

### 7.4 foldと補正

k個すべての評価foldに結果を出す。effect.estimateを参照し、評価可能なfoldをnullにしない。評価不能時は理由と各群Nを返す。

今回の補正選択肢はBHのみ。未知名・未実装名は422。alphaは0と1の間。未検証の「fold別pをまとめて一つのp」にしない。独立検証でBHを使う場合も、適用仮定と事前固定したfamilyの範囲を明記する。

pを表示用に丸めて0として保存しない。保存値は計算値、表示は必要に応じ科学表記とする。underflowは表示上の0と区別して診断を出す。

## 8. 感度分析とモデル

感度分析のcandidateは型付きにする。subgroup_diffに群/比較群がない場合422。typeをkpiへ自動変更しない。

baselineとsensitivityは同一AnalysisFrame、同一estimand、同一重み、同一比較方向で、変わるのは明示された除外集合だけ。両群の有効N、効果、区間、除外理由を返す。非該当/欠損コードを外れ値判定へ渡さない。

単一平均の区間はStudent t(n-1)、群差はWelch tと名称も分ける。N不足・非有限分散では区間null。isRobustは「指定した除外規則の範囲で結果が維持された」を意味し、欠損機構や因果性まで頑健と主張しない。

KDAは共通context/revision/AnalysisFrameへ移行する。定数目的の拒否と決定木人数の修正を維持する。学習に使った人数、除外数、元scopeCountを別表示する。未対応の調査ウェイトを通常の独立行推測へ黙って使わない。

## 9. パッケージとコードブック移送

### 9.1 通常取込の予約ID

通常CSVの予約内部列が不正なら422で取込を中止し、元の値を上書きしない。外部ID列の採用は明示オプションとし、元列をデータとして保持する。正規パッケージ復元に限り、検証済み内部rowIdを保持してよい。

### 9.2 パッケージv2

必須の論理構成はmanifest、raw.parquet、current.parquet、typed codebook、mask、sessionState、provenance。CSVは可読出力であり型付き原本の代用にしない。

取り込む前に、ZIPエントリ名の一意性、許可された相対パス、非圧縮サイズの上限、manifestによる全payload網羅、SHA-256、schema型、ID参照を検査する。圧縮後のサイズだけで安全判定しない。SHA一致は出所の認証ではない。

rawとcurrentは同じ行数であることだけでは十分でない。列追加を含む来歴を考慮して元列/派生列の対応とrow identityを検証し、rawの値をcurrentで作り直さない。取込途中で失敗したら新dataset関連のファイルをすべて削除してロールバックする。

### 9.3 IDと履歴の再割当て

新datasetIdをmeta/codebook/mask/sessionStateのactive参照に反映する。元IDはsourceDatasetIdとして保持する。

移送された旧操作履歴はreadOnlyHistoryへ保存し、新しい編集履歴はimport rootから始める。今回のパッケージは旧undo用snapshot一式の再生を保証しないため、存在しないsnapshotへのUndo/Redoを表示しない。この制約と、raw/currentが復元されることは別である。

### 9.4 コードブックJSON

JSON export/importは列設定だけでなくweightConfig/surveyDesignを含むtyped codebook全体を対象とする。columnId対応を検証してから設定参照を置換する。出力できるのに入力で黙って捨てるフィールドを作らない。

旧schema更新、コードブック編集、JSON取込、package取込は同じvalidation/commitサービスを使う。更新後のコードブックを必ず正規モデルで再検証し、同一schemaRevisionで原子的に保存する。

## 10. フロントと配布

weightの解除、survey/frequency切替、設計解除をレスポンスの確定設定へ同期する。計算結果に適用した設定と、現在編集している設定を混在させない。

セルのドリルダウン、探索候補、補完previewは作成時contextを保持し、revisionが変わったらstaleを表示して適用ボタンを無効化する。バックエンドの409を受けても古い値を最新結果のように表示しない。

静的配信はresolve後に公開root配下のみ許可する。公開外、絶対パス、上位参照、外向きsymlinkは404。SPAの未知画面ルートをindexへ返すことと、任意ファイルを返すことを分ける。

ランチャーはrequirements内容hash、Python実体/version、導入結果をstampへ記録し、変更時は再検証する。モジュールのimport成功だけでは指定版一致の証拠にならない。実行パスは引用し、引数文字列と混ぜない。

## 11. 実装順と完了条件

|順番|実装単位|完了条件|
|---|---|---|
|1|PK01/PK02、静的配信境界、誤った確認的表示の停止|原本を失わず、公開外ファイルを返さず、未保証のp/区間を出さない。|
|2|typed codebook、AnalysisFrame、共通context、cache|AV01〜AV06/AV09、CTX01/02/05、IM02の不変条件が通る。|
|3|補完と移送|IM01、PK03〜PK05を修正し、H01〜H04を後退させない。|
|4|weight/MA/相関/設計gate|W01〜W09、SD01〜SD07、R reference条件が成立。|
|5|候補固定・安定性・独立検証・感度|V01〜V07、SN01〜SN03の数値・状態が一致。|
|6|表示・sampling・配布|AV07/08/10、CTX04/06、UI01、DEP01を受入。|

順番は共通基盤を先に直すためのもの。各機能がそれぞれ専用の欠損/得点変換を足して完成したと扱わない。

### 自動テストの完了条件

今回出力した70件はすべて通常assertionであり、現版では17 PASS/53 FAIL。修正後は指定ネイティブ環境で70 PASS/0 FAIL/0 ERROR/0 SKIPを必要条件とする。失敗件数を減らすためにcase削除、expectedFailure、fallback期待値へ変更しない。

この70件は主要契約の最小セットで、全設計・全GUIを覆わない。実装時には0/N=1/全部欠損/非該当/極端重み/ラベル変更/行並べ替え/部分選択/Undo後などの同値・境界条件を追加する。追加テストによる新しい欠陥は今回の49項目に押し込めず別IDを付ける。

### 必須の追加受入（今回未実施）

|ID|環境と手順|受入値|
|---|---|---|
|E2E-U01|ブラウザで30000行以上の合成表を作り、全件・active・selected・sampledで10000件超のセルをクリック。応答とnetwork payloadを保存。|再取得rowId集合が表作成scope内の当該セルと完全一致。選択外を含まない。|
|E2E-U02|保存weightありで「ウェイトなし」→survey→frequency→別weightを切替。MA/summary/相関/クロス表を比較。|明示noneが解除として送信され、全画面の適用状態・診断母数が一致。旧設計は必要時解除。|
|E2E-U03|コードブック編集後、既存候補/補完preview/表セルを操作。Undo/Redoも実施。|staleを表示し、旧世代の適用を拒否。再計算後のみ操作可能。|
|E2E-U04|順序/逆転/99欠損の同一回答をPCP・表・分布・LOESSで選択。|valueSpaceを合わせたとき同じ得点と同じ回答者集合。|
|E2E-P01|Windowsの空白を含むプロジェクト/Pythonパス。requirements変更、既存venv、オフライン失敗も確認。|正しい実体で起動、依存差分を検知、導入失敗を隠さない。|
|REF-S01|R surveyの固定versionでRao–Scottの全対応fixtureを比較。|F/df/p/共分散/状態が規定許容差内で一致。|
|REF-S02|provided designのfiltered scope/質問欠損、lonely、FPC指定をAPIとUIで確認。|この版で未対応の推測はunavailable/422となり、数値や星を残さない。|
|E2E-U05|LOESS画面とCSV/JSON出力を確認。|未対応95%帯を表示せず、intervalStatusが一致。|

## 12. 禁止する代替修正

欠損コードを一律0にする、subsetでカテゴリ順を作り直す、逆転上限を観測最大へ広げる、全重みを整数化する、surveyに生Pearson/Kish補正Pearsonを使う、invalid weight時だけ非加重へ戻す、pだけ消してセル星を残す、後付けholdoutを独立検証と呼ぶ、rawをcurrentで再生成する、scope欠落時にallへ戻す、テストを既知不具合だからskipする――これらは本仕様の修正として受理しない。

## 13. 統計資料

[R1] survey `svydesign`：設計変数、層・PSUの入れ子、欠損/FPCの前提。  
[R2] survey `svychisq`：Rao–Scott第2次補正。  
[R3] survey Lonely PSUs：単独PSUの扱い。  
[R4] scikit-learn Common pitfalls：前処理一致と情報漏洩。

最小原文引用と参照先は`AUDIT_REPORT.md`と`SOURCES.md`。本仕様の「未対応で止める」範囲は、文献がその手法を不可能としている意味ではなく、今回の製品受入を安全に固定するための設計判断である。
