# 根拠資料と照合範囲

参照日：2026-09-11。

## 外部一次資料

[R1] Thomas Lumley, R survey, `svydesign`。  
`https://r-survey.r-forge.r-project.org/survey/html/svydesign.html`

設計変数の欠損検査、層内PSU再利用のnest設定、層化での独立行設計、FPCの意味を参照。ページ末尾の版は3.19。現在のR実行結果を取得したという意味ではない。

[R2] R survey, `svychisq`。  
`https://r-survey.r-forge.r-project.org/survey/html/svychisq.html`

第2次Rao–Scott F補正、Satterthwaite近似、対照行列の方式を参照。ページ末尾の版は3.18。

[R3] Thomas Lumley, Lonely PSUs。  
`https://r-survey.r-forge.r-project.org/survey/exmample-lonely.html`

非確実抽出の単独PSU層をデフォルトで失敗とすることと、複数の明示的調整方針が存在することを参照。記事の最終更新は2006年。この製品仕様はそれらからfailを選ぶ。

[R4] scikit-learn, Common pitfalls and recommended practices。  
`https://scikit-learn.org/stable/common_pitfalls.html`

閲覧時は1.9.1ドキュメント。前処理を学習/評価で一致させること、評価情報を選択へ混入させないことを参照。アンケートの選択後推測への適用は本監査の推論であり、同ページがDAVIS-PCPを直接評価したものではない。

## 既存プロジェクト資料

Library内 `DAVIS_PCP_WEIGHTS_B04_ideal_fix_spec.md` のsurvey/frequency分離、survey既定推測OFF、明示Rao–Scott第2次、セル星抑止という既決定を維持した。FPC/複製重みや高度な設計を未検証のまま受理しない。

Library内 `DAVIS-PCP/davis-pcp-fullstack-v2.0.0/backend/tests/m0/test_api.py` と `test_ordering.py` のunittest.TestCase形式を参照。今回ZIPにはそのテスト一式は同梱されていない。既存の最新版全テストを実行したとは主張しない。

## 現版ソース

アップロードZIPのSHA-256と全Pythonシンボル行範囲は`source_index.json`。監査用probeとunittest以外のアプリ実装ファイルを変更していないことを、ZIP内のソースhashと展開後のhashを照合する。

ブラウザUIの根拠は現在配布された `frontend/dist/assets/index-5mARUBaL.js`。監査用整形版は元TS/TSXソースではない。解析用整形版はevidence/frontend.pretty.jsに同梱する。元のminified JSはユーザー添付ZIPを参照する。
